<html>
    <head>
      <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../css/materialize.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

      <title>{{config('app.name')}} - Periodic table</title>
      <link rel="shortcut icon" type="image/png" href="../images/favico.png"/>


      <style>
      .wrapper {
       	width:1050px;
        margin:30px auto;
        position:relative;
      }
      .main:after {
       	clear:both;
        content:"";
        display:table;
      }
      .main li {
       	width:56px;
        height:70px;
        border:0px solid rgba(0,0,0,0.3);
        box-shadow:inset 0 1px 0 rgba(255,255,255,0.4);
        position:relative;
        font-size:18px;
        float:left;
        padding:0 2px;
        margin:1px;
        cursor:pointer;
        padding-top:20px;
        overflow:hidden;
        transition:all .2s ease-in;
        text-shadow:0 1px 0 rgba(255,255,255,0.2);
      }
      .main li span {
        display:block;
        line-height:1;
        font-size:9px;
        color:black;
        padding-top:7px;
      }
      .main .empty {
       	border:none;
        box-shadow:none;
        cursor:default;
      }
      .deactivate {
       	opacity:0.5;
        -webkit-filter:grayscale(70%);
        filter:grayscale(70%);
      }
      .main li:before,
      .main li:after {
       	content:attr(data-pos);
        position:absolute;
        top:3px;
        left:3px;
        color:black;
        font-size:8px;
        line-height:1;
      }
      .main li:after {
        content:attr(data-nb);
        left:auto;
        right:3px;
      }
      .main li:hover {
       	transform:scale(1.2);
        z-index:100;
        box-shadow: 0 0 10px rgba(0,0,0,0.3);
      }
      .main .empty:hover {
       	box-shadow:none;
        transform:none;
      }
      .type-0 { background:#fff; }
      .type-1 { background:#dddddd; }
      .type-2 { background:#a8bffa; }
      .type-3 { background:#F8B707; }
      .type-4 { background:#f3f300; }
      .type-5 { background:#3bd93b; }
      .type-6 { background:#dd9999; }
      .type-7 { background:#4CAFFA; }
      .type-8 { background:#ffaa88; }
      .type-9 { background:#ddaacc; }
      .cat-0 { color:#222; }
      .cat-1 { color:#0000dc; }
      .cat-2 { color:#b10601; }
      .cat-3 { color:#555; }
      .legend {
       	position:absolute;
        top:0;
        left:20%;
        padding:10px;
        font-size:11px;
        background:#f1edec;
        border:1px solid rgba(0,0,0,0.2);
        border-radius:15px;
        box-shadow:
          inset 0 1px 1px white,
          inset 0 -5px 3px #dddcdb,
          0 0 10px rgba(0,0,0,0.2);
      }
      .legend:after {
       	content:"";
        display:table;
        clear:table;
      }
      .legend ul { float:left; list-style: none; }
      .legend .list-2 {
       	margin-left:40px;
        width:200px;
      }
      .legend .list-1 li { margin:7px 0; }
      .legend .list-1 li:first-of-type { margin-top: 2px; }
      .legend .list-1 span {
       	border:1px solid black;
        display:inline-block;
        padding:3px;
        width:20px;
        text-align:center;
        height:20px;
        margin-right:5px;
      }
      .legend .list-2 li {
        margin:2px;
        padding:3px;
       	float:left;
        border:1px solid rgba(0,0,0,0.2);
        width:48%;
        cursor:pointer;
      }
      </style>

    </head>

    <body class="grey lighten-3">
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="../js/bin/materialize.js"></script>

      <script>
          $( document ).ready(function() {
              $(".dropdown-button").dropdown();
              $('.modal').modal();
          });
      </script>

      <ul id="dropdown1" class="dropdown-content">
        <li><a href="#modal_account" >{{ Auth::user()->name }}</a></li>
        <li><a href="{{ url('/logout') }}"
            onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();">
            Logout
        </a>

        <form id="logout-form" action="{{ url('/logout') }}" method="POST" style="display: none;">
            {{ csrf_field() }}
        </form></li>
      </ul>

      <div class="navbar-fixed">
      <nav>
        <div class="nav-wrapper">
          <a href="../cluster" class="brand-logo">{{config('app.name')}}</a>
          <ul class="right">
            <li><a class="dropdown-button" href="#!" data-activates="dropdown1">{{ Auth::user()->name }}<i class="material-icons right">arrow_drop_down</i></a></li>
          </ul>
        </div>
      </nav>
    </div>
  </br>
    <div class="container">
      <nav class="grey lighten-3" style="    box-shadow: none;">
        <div class="nav-wrapper">
          <div class="col s12">
            <a href="../cluster" class="breadcrumb grey-text">Home</a>
            <a href="#" class="breadcrumb black-text">Periodic table</a>
          </div>
        </div>
      </nav>
      <div class="row">
        <div class="wrapper">
          <ul class="main">

            <!-- ROW 1 -->

            <a href="#H"><li data-pos="1" data-nb="1.0079" class="type-1 cat-2">H<span>Hydrogen</span></li></a>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>

            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>

            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>

            <li class="empty"></li>
            <li class="empty"></li>
            <a href="#He"><li data-pos="2" data-nb="4.0026" class="type-2 cat-2">He<span>Helium</span></li></a>

            <!-- ROW 2 -->

            <a href="#Li"><li data-pos="3" data-nb="6.941" class="type-3 cat-0">Li<span>Lithium</span></li></a>
            <a href="#Be"><li data-pos="4" data-nb="9.0122" class="type-4 cat-0">Be<span>Beryllium</span></li></a>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>

            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>

            <li class="empty"></li>
            <li class="empty"></li>
            <a href="#B"><li data-pos="5" data-nb="10.811" class="type-5 cat-0">B<span>Boron</span></li></a>
            <a href="#C"><li data-pos="6" data-nb="12.011" class="type-5 cat-0">C<span>Carbon</span></li></a>
            <a href="#N"><li data-pos="7" data-nb="14.007" class="type-5 cat-2">N<span>Nitrogen</span></li></a>

            <a href="#O"><li data-pos="8" data-nb="15.999" class="type-5 cat-2">O<span>Oxygen</span></li></a>
            <a href="#F"><li data-pos="9" data-nb="18.998" class="type-5 cat-2">F<span>Fluorine</span></li></a>
            <a href="#Ne"><li data-pos="10" data-nb="20.180" class="type-2 cat-2">Ne<span>Neon</span></li></a>

            <!-- ROW 3 -->

            <a href="#Na"><li data-pos="11" data-nb="22.990" class="type-3 cat-0">Na<span>Sodium</span></li></a>
            <a href="#Mg"><li data-pos="12" data-nb="24.305" class="type-4 cat-0">Mg<span>Magnesium</span></li></a>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>

            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>

            <li class="empty"></li>
            <li class="empty"></li>
            <a href="#Al"><li data-pos="13" data-nb="26.982" class="type-7 cat-0">Al<span>Aluminium</span></li></a>
            <a href="#Si"><li data-pos="14" data-nb="28.086" class="type-5 cat-0">Si<span>Silicon</span></li></a>
            <a href="#P"><li data-pos="15" data-nb="30.974" class="type-5 cat-0">P<span>Phosphorus</span></li></a>

            <a href="#S"><li data-pos="16" data-nb="32.065" class="type-5 cat-0">S<span>Sulfur</span></li></a>
            <a href="#Cl"><li data-pos="17" data-nb="35.453" class="type-5 cat-2">Cl<span>Chlorine</span></li></a>
            <a href="#Ar"><li data-pos="18" data-nb="39.948" class="type-2 cat-2">Ar<span>Argon</span></li></a>

            <!-- ROW 4 -->

            <a href="#K"><li data-pos="19" data-nb="39.098" class="type-3 cat-0">K<span>Potassium</span></li></a>
            <a href="#Ca"><li data-pos="20" data-nb="40.078" class="type-4 cat-0">Ca<span>Calcium</span></li></a>
            <a href="#Sc"><li data-pos="21" data-nb="44.956" class="type-6 cat-0">Sc<span>Scandium</span></li></a>
            <a href="#Ti"><li data-pos="22" data-nb="47.867" class="type-6 cat-0">Ti<span>Titanium</span></li></a>
            <a href="#V"><li data-pos="23" data-nb="50.942" class="type-6 cat-0">V<span>Vanadium</span></li></a>

            <a href="#Cr"><li data-pos="24" data-nb="51.996" class="type-6 cat-0">Cr<span>Chromium</span></li></a>
            <a href="#Mn"><li data-pos="25" data-nb="54.938" class="type-6 cat-0">Mn<span>Manganese</span></li></a>
            <a href="#Fe"><li data-pos="26" data-nb="55.845" class="type-6 cat-0">Fe<span>Iron</span></li></a>
            <a href="#Co"><li data-pos="27" data-nb="58.933" class="type-6 cat-0">Co<span>Cobalt</span></li></a>
            <a href="#Ni"><li data-pos="28" data-nb="58.693" class="type-6 cat-0">Ni<span>Nickel</span></li></a>

            <a href="#Cu"><li data-pos="29" data-nb="63.546" class="type-6 cat-0">Cu<span>Copper</span></li></a>
            <a href="#Zn"><li data-pos="30" data-nb="65.39" class="type-7 cat-0">Zn<span>Zinc</span></li></a>
            <a href="#Ga"><li data-pos="31" data-nb="69.723" class="type-7 cat-0">Ga<span>Gallium</span></li></a>
            <a href="#Ge"><li data-pos="32" data-nb="72.64" class="type-7 cat-0">Ge<span>Germanium</span></li></a>
            <a href="#As"><li data-pos="33" data-nb="74.922" class="type-5 cat-0">As<span>Arsenic</span></li></a>

            <a href="#Se"><li data-pos="34" data-nb="78.96" class="type-5 cat-0">Se<span>Selenium</span></li></a>
            <a href="#Br"><li data-pos="35" data-nb="79.904" class="type-5 cat-1">Br<span>Bromine</span></li></a>
            <a href="#Kr"><li data-pos="36" data-nb="83.80" class="type-2 cat-2">Kr<span>Krypton</span></li></a>

            <!-- ROW 5 -->

            <a href="#Rb"><li data-pos="37" data-nb="85.468" class="type-3 cat-0">Rb<span>Rubidium</span></li></a>
            <a href="#Sr"><li data-pos="38" data-nb="87.62" class="type-4 cat-0">Sr<span>Strontium</span></li></a>
            <a href="#Y"><li data-pos="39" data-nb="88.906" class="type-6 cat-0">Y<span>Yttrium</span></li></a>
            <a href="#Zr"><li data-pos="40" data-nb="91.224" class="type-6 cat-0">Zr<span>Zirconium</span></li></a>
            <a href="#Nb"><li data-pos="41" data-nb="92.906" class="type-6 cat-0">Nb<span>Niobium</span></li></a>

            <a href="#Mo"><li data-pos="42" data-nb="95.94" class="type-6 cat-0">Mo<span>Molybdenum</span></li></a>
            <a href="#Tc"><li data-pos="43" data-nb="(96)" class="type-6 cat-0">Tc<span>Technetium</span></li></a>
            <a href="#Ru"><li data-pos="44" data-nb="101.07" class="type-6 cat-0">Ru<span>Ruthenium</span></li></a>
            <a href="#Rh"><li data-pos="45" data-nb="102.91" class="type-6 cat-0">Rh<span>Rhodium</span></li></a>
            <a href="#Pd"><li data-pos="46" data-nb="106.42" class="type-6 cat-0">Pd<span>Palladium</span></li></a>

            <a href="#Ag"><li data-pos="47" data-nb="107.87" class="type-6 cat-0">Ag<span>Silver</span></li></a>
            <a href="#Cd"><li data-pos="48" data-nb="112.41" class="type-7 cat-0">Cd<span>Cadmium</span></li></a>
            <a href="#In"><li data-pos="49" data-nb="114.82" class="type-7 cat-0">In<span>Indium</span></li></a>
            <a href="#Sn"><li data-pos="50" data-nb="118.71" class="type-7 cat-0">Sn<span>Tin</span></li></a>
            <a href="#Sb"><li data-pos="51" data-nb="121.76" class="type-7 cat-0">Sb<span>Antimony</span></li></a>

            <a href="#Te"><li data-pos="52" data-nb="127.60" class="type-5 cat-0">Te<span>Tellurium</span></li></a>
            <a href="#I"><li data-pos="53" data-nb="126.90" class="type-5 cat-0">I<span>Iodine</span></li></a>
            <a href="#Xe"><li data-pos="54" data-nb="131.29" class="type-2 cat-2">Xe<span>Xenon</span></li></a>

            <!-- ROW 6 -->

            <a href="#Cs"><li data-pos="55" data-nb="132.91" class="type-3 cat-0">Cs<span>Caesium</span></li></a>
            <a href="#Ba"><li data-pos="56" data-nb="137.33" class="type-4 cat-0">Ba<span>Barium</span></li></a>
            <a href="#La-Lu"><li data-pos="57-71" class="type-8 black-text">La-Lu<span>Lanthanide</span></li></a>
            <a href="#Hf"><li data-pos="72" data-nb="178.49" class="type-6 cat-0">Hf<span>Hafnium</span></li></a>
            <a href="#Ta"><li data-pos="73" data-nb="180.95" class="type-6 cat-0">Ta<span>Tantalum</span></li></a>

            <a href="#W"><li data-pos="74" data-nb="183.64" class="type-6 cat-0">W<span>Tungsten</span></li></a>
            <a href="#Re"><li data-pos="75" data-nb="186.21" class="type-6 cat-0">Re<span>Rhenium</span></li></a>
            <a href="#Os"><li data-pos="76" data-nb="190.23" class="type-6 cat-0">Os<span>Osmium</span></li></a>
            <a href="#Ir"><li data-pos="77" data-nb="192.22" class="type-6 cat-0">Ir<span>Iridium</span></li></a>
            <a href="#Pt"><li data-pos="78" data-nb="195.08" class="type-6 cat-0">Pt<span>Platinum</span></li></a>

            <a href="#Au"><li data-pos="79" data-nb="196.97" class="type-6 cat-0">Au<span>Gold</span></li></a>
            <a href="#Hg"><li data-pos="80" data-nb="200.59" class="type-7 cat-1">Hg<span>Mercury</span></li></a>
            <a href="#Tl"><li data-pos="81" data-nb="204.38" class="type-7 cat-0">Tl<span>Thallium</span></li></a>
            <a href="#Pb"><li data-pos="82" data-nb="207.2" class="type-7 cat-0">Pb<span>Lead</span></li></a>
            <a href="#Bi"><li data-pos="83" data-nb="208.96" class="type-7 cat-0">Bi<span>Bismuth</span></li></a>

            <a href="#Po"><li data-pos="84" data-nb="(209)" class="type-7 cat-0">Po<span>Polonium</span></li></a>
            <a href="#At"><li data-pos="85" data-nb="(210)" class="type-5 cat-0">At<span>Astatine</span></li></a>
            <a href="#Rn"><li data-pos="86" data-nb="(222)" class="type-2 cat-2">Rn<span>Radon</span></li></a>

            <!-- ROW 7 -->

            <a href="#Fr"><li data-pos="87" data-nb="(223)" class="type-3 cat-0">Fr<span>Francium</span></li></a>
            <a href="#Ra"><li data-pos="88" data-nb="(226)" class="type-4 cat-0">Ra<span>Radium</span></li></a>
            <a href="#Ac-Lr"><li data-pos="89-103" class="type-9 black-text">Ac-Lr<span>Actinide</span></li></a>
            <a href="#Rf"><li data-pos="104" data-nb="(261)" class="type-6 cat-3">Rf<span>Rutherfodum</span></li></a>
            <a href="#Db"><li data-pos="105" data-nb="(262)" class="type-6 cat-3">Db<span>Dubnium</span></li></a>

            <a href="#Sg"><li data-pos="106" data-nb="(266)" class="type-6 cat-3">Sg<span>Seaborgium</span></li></a>
            <a href="#Bh"><li data-pos="107" data-nb="(264)" class="type-6 cat-3">Bh<span>Bohrium</span></li></a>
            <a href="#Hs"><li data-pos="108" data-nb="(277)" class="type-6 cat-3">Hs<span>Hassium</span></li></a>
            <a href="#Mt"><li data-pos="109" data-nb="(268)" class="type-6 cat-3">Mt<span>Meitnerium</span></li></a>
            <a href="#Ds"><li data-pos="110" data-nb="(281)" class="type-6 cat-3">Ds<span>Damstadium</span></li></a>

            <a href="#Rg"><li data-pos="111" data-nb="(272)" class="type-6 cat-3">Rg<span>Roentgenium</span></li></a>
            <a href="#Cn"><li data-pos="112" data-nb="(285)" class="type-7 cat-3">Cn<span>Copernicium</span></li></a>
            <a href="#Nh"><li data-pos="113" data-nb="(285)" class="type-7 cat-3">Nh<span>Nihonium</span></li></a>
            <a href="#Fl"><li data-pos="114" data-nb="(289)" class="type-7 cat-3">Fl<span>Flerovium</span></li></a>
            <a href="#Mc"><li data-pos="115" data-nb="(288)" class="type-7 cat-3">Mc<span>Moscovium</span></li></a>

            <a href="#Lv"><li data-pos="116" data-nb="(292)" class="type-7 cat-3">Lv<span>Livermorium</span></li></a>
            <a href="#Ts"><li data-pos="117" data-nb="(294)" class="type-0 cat-3">Ts<span>Tennessine</span></li></a>
            <a href="#Og"><li data-pos="118" data-nb="(294)" class="type-2 cat-3">Og<span>Oganesson</span></li></a>

            <!-- ROW blank -->

            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>

            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>

            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>

            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>

            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <a href="#La"><li data-pos="57" data-nb="138.90547" class="type-8 black-text">La<span>Lanthanum</span></li></a>
            <a href="#Ce"><li data-pos="58" data-nb="140.116" class="type-8 black-text">Ce<span>Cerium</span></li></a>

            <a href="#Pr"><li data-pos="59" data-nb="140.90765" class="type-8 black-text">Pr<span>Praseodymium</span></li></a>
            <a href="#Nd"><li data-pos="60" data-nb="144.242" class="type-8 black-text">Nd<span>Neodymium</span></li></a>
            <a href="#Pm"><li data-pos="61" data-nb="145" class="type-8 black-text">Pm<span>Promethium</span></li></a>
            <a href="#Sm"><li data-pos="62" data-nb="150.36" class="type-8 black-text">Sm<span>Samarium</span></li></a>
            <a href="#Eu"><li data-pos="63" data-nb="151.964" class="type-8 black-text">Eu<span>Europium</span></li></a>

            <a href="#Gd"><li data-pos="64" data-nb="157.25" class="type-8 black-text">Gd<span>Gadolinium</span></li></a>
            <a href="#Tb"><li data-pos="65" data-nb="158.92535" class="type-8 black-text">Tb<span>Terbium</span></li></a>
            <a href="#Dy"><li data-pos="66" data-nb="162.5" class="type-8 black-text">Dy<span>Dysprosium</span></li></a>
            <a href="#Ho"><li data-pos="67" data-nb="164.93032" class="type-8 black-text">Ho<span>Holmium</span></li></a>
            <a href="#Er"><li data-pos="68" data-nb="167.259" class="type-8 black-text">Er<span>Erbium</span></li></a>

            <a href="#Tm"><li data-pos="69" data-nb="168.93421" class="type-8 black-text">Tm<span>Thulium</span></li></a>
            <a href="#Yb"><li data-pos="70" data-nb="173.045" class="type-8 black-text">Yb<span>Ytterbium</span></li></a>
            <a href="#Lu"><li data-pos="71" data-nb="174.9668" class="type-8 black-text">Lu<span>Lutetium</span></li></a>

            <!-- ROW last -->


            <li class="empty"></li>
            <li class="empty"></li>
            <li class="empty"></li>
            <a href="#Ac"><li data-pos="89" data-nb="227" class="type-9 black-text">Ac<span>Actinium</span></li></a>
            <a href="#Th"><li data-pos="90" data-nb="232.03806" class="type-9 black-text">Th<span>Thorium</span></li></a>

            <a href="#Pa"><li data-pos="91" data-nb="231.03588" class="type-9 black-text">Pa<span>Protactinium</span></li></a>
            <a href="#U"><li data-pos="92" data-nb="238.02891" class="type-9 black-text">U<span>Uranium</span></li></a>
            <a href="#Np"><li data-pos="93" data-nb="237" class="type-9 black-text">Np<span>Neptunium</span></li></a>
            <a href="#Pu"><li data-pos="94" data-nb="244" class="type-9 black-text">Pu<span>Plutonium</span></li></a>
            <a href="#Am"><li data-pos="95" data-nb="243" class="type-9 black-text">Am<span>Americium</span></li></a>

            <a href="#Cm"><li data-pos="96" data-nb="247" class="type-9 black-text">Cm<span>Curium</span></li></a>
            <a href="#Bk"><li data-pos="97" data-nb="247" class="type-9 black-text">Bk<span>Berkelium</span></li></a>
            <a href="#Cf"><li data-pos="98" data-nb="251" class="type-9 black-text">Cf<span>Californium</span></li></a>
            <a href="#Es"><li data-pos="99" data-nb="252" class="type-9 black-text">Es<span>Einsteium</span></li></a>
            <a href="#Fm"><li data-pos="100" data-nb="257" class="type-9 black-text">Fm<span>Fermium</span></li></a>

            <a href="#Md"><li data-pos="101" data-nb="258" class="type-9 black-text">Md<span>Mendelevium</span></li></a>
            <a href="#No"><li data-pos="102" data-nb="259" class="type-9 black-text">No<span>Nobelium</span></li></a>
            <a href="#Lr"><li data-pos="103" data-nb="262" class="type-9 black-text">Lr<span>Lawrencium</span></li></a>

          </ul>

          <!-- <div class="legend">
            <ul class="list-1">
              <li class="cat-0"><span>C</span>Solid</li>
              <li class="cat-1"><span>Hg</span>Liquid</li>
              <li class="cat-2"><span>H</span>Gas</li>
              <li class="cat-3"><span>Rf</span>Unknown</li>
            </ul>

            <ul class="list-2">
              <li class="type-3">Alkadi metals</li>

              <li class="type-8">Lanthanoids</li>
              <li class="type-9">Actinoids</li>
              <li class="type-7">Poor metals</li>
              <li class="type-2">Noble gases</li>
              <li class="type-6">Transition metals</li>
              <li class="type-5">Other non-metals</li>
              <li class="type-4">Alkadine earth metals</li>
            </ul>
          </div> -->

          @foreach ($elements as $element)
            <!-- Modal Structure -->
            <div id="{{$element->symbol}}" class="modal modal-fixed-footer">
              <div class="modal-content">

                <h4>{{$element->name}}</h4>

                </br>
                <span class="sub-menu-item"><b>Atomic number :</b> {{$element->atomic_number}}</span>
                </br>
                <span class="sub-menu-item"><b>Symbol :</b> {{$element->symbol}}</span>
                </br>
                <span class="sub-menu-item"><b>Group :</b> {{$element->group}}</span>
                </br>
                <span class="sub-menu-item"><b>Block :</b> {{$element->block}}</span>
                </br>
                <span class="sub-menu-item"><b>Period :</b> {{$element->period}}</span>
                </br>
                <span class="sub-menu-item"><b>Atomic weight :</b> {{$element->atomic_weight}}</span>

                </br>
                <span class="sub-menu-item"><b>Dicoverer :</b> {{$element->discoverer}}</span>
                </br>
                <span class="sub-menu-item"><b>Year discovered :</b> {{$element->year_discovered}}</span>
                </br>
                <span class="sub-menu-item"><b>Electron configuration :</b> {{$element->electron_configuration}}</span>
                </br>
                <span class="sub-menu-item"><b>Oxidation state :</b> {{$element->oxidation_state}}</span>
                </br>
                <span class="sub-menu-item"><b>Ionic charge :</b> {{$element->ionic_charge}}</span>
                </br>
                <span class="sub-menu-item"><b>Uses :</b></span>
              </br>
                <a href="#uses_{{$element->symbol}}"><button class="btn waves-effect waves-light" type="submit" name="action">Edit uses
                </button></a>
              </br></br>
              <?php echo nl2br( "<p class='sub-menu-item'>" . $element->uses . '</p>', true); ?>
              </div>


              <div class="modal-footer">
                <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat ">Close</a>
              </div>
            </div>

            <div id="uses_{{$element->symbol}}" class="modal modal-fixed-footer">
              <div class="modal-content">
                <span class="card-title menu-item">Uses of {{$element->name}}</span>
              </br></br>
                <div class="row">
                  <form class="col s12" action="../cluster/periodictable/{{$element->symbol}}" method="POST">
                    {{ csrf_field() }}
                    <div class="row">
                      <div class="input-field col s12">
                        <textarea id="textarea1" name="uses" class="materialize-textarea">{{$element->uses}}</textarea>
                        <label for="textarea1">Uses</label>
                      </div>
                    </div>

                </div>

              </div>
              <div class="modal-footer">
                <button class="btn waves-effect waves-light" type="submit" name="action">Save
                </button>
              </div>
              </form>
            </div>


          @endforeach

      </div>
    </div>
    @if (count($errors) > 0)
      @foreach ($errors->all() as $error)
          <script>
            Materialize.toast('{{ $error }}', 3000, 'rounded');
          </script>

      @endforeach
    @endif

    </body>
  </html>
