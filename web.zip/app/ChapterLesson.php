<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChapterLesson extends Model
{
    //
}
