<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

use App\Section;
use App\Teacher;
use App\User;
use App\Student;

class AdminController extends Controller
{
    function home(){
        return view('admin.home');
    }

    function section(){
        $sections = Section::all();

        foreach ($sections as $section) {
            if ($section->teacher_id != -1) {
              $section->get_teacher_info();
            }

        }

        return view('admin.section', ['sections' => $sections]);
    }

    function teacher(){
        $teachers = User::where('position', 'teacher')->get();

        foreach ($teachers as $teacher) {
            $teacher->get_teacher_info();
        }

        return view('admin.teacher', ['teachers' => $teachers]);
    }

    function student(){
        $students = Student::orderBy('lastname', 'asc')->get();
        $sections = Section::where('teacher_id', '!=', -1)->get();

        foreach ($students as $student) {
            $student->get_students_section();
        }

        return view('admin.student', ['students' => $students, 'sections' => $sections]);
    }

    function cluster(){
        $cluster = User::where('position', 'cluster')->first();
        return view('admin.cluster_stages', ['cluster' => $cluster]);
    }

    function account(){
        return view('admin.account');
    }

    function editinfo(Request $request){
      $this->validate($request, [
          'username' => 'required|min:5',
          'name' => 'required',
          'lastname' => 'required',
          'middlename' => 'required',
          'birthday' => 'required',
      ]);

      $user = Auth::user();
      $user->username = $request->input('username');
      $user->name = $request->input('name');
      $user->lastname = $request->input('lastname');
      $user->middlename = $request->input('middlename');
      $user->birthday = $request->input('birthday');

      $user->save();

      return back()->withErrors(['Success!']);

    }

    function changepassword(Request $request){
      $this->validate($request, [
          'old_password' => 'required',
          'password' => 'required|min:6|confirmed'
      ]);

      $user = Auth::user();
      if (Hash::check($request->input('old_password'), $user->password)) {
          $user->password = Hash::make($request->input('password'));
          $user->save();
      }else{
          return back()->withErrors(['Incorrect password']);
      }
      return back()->withErrors(['Success!']);

    }
}
