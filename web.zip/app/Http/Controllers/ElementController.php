<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Element;

class ElementController extends Controller
{
    function edit_element_uses(Request $request, $symbol){
          $this->validate($request, [
              'uses' => 'required',
          ]);

          $element = Element::where('symbol', $symbol)->first();

          if ($element == null) {
                return back()->withErrors(['Element not found']);
          }

          $element->uses = $request->input('uses');
          $element->save();

          return back()->withErrors(['Element updated!']);
    }

    function get_element($symbol){
        $element = Element::where('symbol', $symbol)->first();

        if ($element == null) {
            return response()->json([
                'error' => 'Element not found.'
            ]);
        }

        return $element->toJson();
    }
}
