<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\File;

class FileController extends Controller
{
    function delete_file($file_id, $stage){
        $file = File::where('id', $file_id)->first();

        if ($file == null) {
            return redirect('/teacher/files');
        }

        $file->delete();
        return redirect('/teacher/files/' . $stage)->withErrors(['File deleted!']);;
    }

    function admin_delete_file($employee_id, $file_id){
        $file = File::where('id', $file_id)->first();

        if ($file == null) {
          return redirect('/admin/teacher/' . $employee_id);
        }

        $stage = $file->stage;

        $file->delete();
        return redirect('/admin/teacher/' . $employee_id . '/files' . '/' . $stage)->withErrors(['File deleted!']);;
    }
}
