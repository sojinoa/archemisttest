<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Question;
use App\User;

class QuestionController extends Controller
{
    function get_questions($stage){
      if ($stage > 5) {
            return redirect('/teacher/quizzes');
        }
        if (!is_numeric($stage)) {
            return redirect('/teacher/quizzes');
        }
        $questions = Question::all()->where('level', $stage)
                                    ->where('teacher_id', Auth::user()->id)
                                    ->sortByDesc("id");

        //return $questions;

        return view('teacher.questions', ['stage' => $stage, 'questions' => $questions]);
    }

    function add_question(Request $request, $stage){
      $this->validate($request, [
          'title' => 'required',
          'choice_a' => 'required',
          'choice_b' => 'required',
          'choice_c' => 'required',
          'choice_d' => 'required',
          'answer' => 'required',
      ]);

      $question = new Question();
      $question->title = $request->input('title');
      $question->level = $stage;
      $question->answer = $request->input('answer');
      $question->choice_1 = $request->input('choice_a');
      $question->choice_2 = $request->input('choice_b');
      $question->choice_3 = $request->input('choice_c');
      $question->choice_4 = $request->input('choice_d');
      $question->teacher_id = Auth::user()->id;

      $question->save();
      return redirect('/teacher/questions/'.$stage)->withErrors(['Question added!']);
    }

    function update_question(Request $request, $question_id){
      $this->validate($request, [
          'title' => 'required',
          'choice_a' => 'required',
          'choice_b' => 'required',
          'choice_c' => 'required',
          'choice_d' => 'required',
          'answer' => 'required',
      ]);

        $question = Question::where('id', $question_id)->first();
        if ($question == null) {
            return redirect('home');
        }
        $question->title = $request->input('title');
        $question->answer = $request->input('answer');
        $question->choice_1 = $request->input('choice_a');
        $question->choice_2 = $request->input('choice_b');
        $question->choice_3 = $request->input('choice_c');
        $question->choice_4 = $request->input('choice_d');
        $question->save();

        return redirect('/teacher/questions/'.$question->level)->withErrors(['Question updated!']);
    }

    function delete_question($question_id){
        $question = Question::where('id', $question_id)->first();
        if ($question == null) {
            return redirect('home');
        }
        $level = $question->level;
        $question->delete();

        return redirect('/teacher/questions/'.$question->level)->withErrors(['Question deleted!']);
    }

    function admin_get_questions($teacher_id, $stage){
      if ($stage > 5) {
            return redirect('/teacher/quizzes');
        }
        if (!is_numeric($stage)) {
            return redirect('/teacher/quizzes');
        }

        $teacher = User::where('id', $teacher_id)->first();
        $teacher->get_teacher_info();

        $questions = Question::all()->where('level', $stage)
                                    ->where('teacher_id', $teacher_id)
                                    ->sortByDesc("id");

        //return $questions;

        return view('admin.questions', ['stage' => $stage, 'questions' => $questions, 'teacher' => $teacher]);
    }
}
