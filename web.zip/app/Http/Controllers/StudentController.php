<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use App\Student;
use App\Section;

class StudentController extends Controller
{
    function add_student(Request $request){
      $this->validate($request, [
          'student_id' => 'required|unique:students',
          'name' => 'required',
          'lastname' => 'required',
          'middlename' => 'required',
          'birthday' => 'required',
          'section_id' => 'required',
      ]);

      $password = str_replace(',', '', str_replace(' ', '', $request->input('birthday')));

      $section = Section::where('id', $request->input('section_id'))->first();

      if ($section == null) {
          return redirect('/admin/student');
      }

      $student = new Student();
      $student->student_id = $request->input('student_id');
      $student->name = $request->input('name');
      $student->lastname = $request->input('lastname');
      $student->middlename = $request->input('middlename');
      $student->birthday = $request->input('birthday');
      $student->section_id = $section->id;
      $student->password = Hash::make(strtolower($password));
      $student->token = str_random(69);

      $student->save();
      return redirect('/admin/student')->withErrors(['Success!']);;
    }

    function confirm_student($student_id){
      $student = Student::where('student_id', $student_id)->first();

      if ($student == null) {
          return redirect('/teacher');
      }

      $student->is_confirmed = 1;
      $student->save();


      return redirect('/teacher/section/' . $student->section_id)->withErrors(['Student confirmed!']);
    }

    function decline_student($student_id){
      $student = Student::where('student_id', $student_id)->first();

      if ($student == null) {
          return redirect('/teacher');
      }

      $section = $student->section_id;

      $student->is_confirmed = 0;
      $student->section_id = -69;
      $student->save();


      return redirect('/teacher/section/' . $section)->withErrors(['Student declined!']);
    }

    function delete_student($student_id){
      $student = Student::where('student_id', $student_id)->first();

      if ($student == null) {
          return redirect('/admin/student');
      }

      $student->delete();


      return redirect('/admin/student/')->withErrors(['Student deleted!']);
    }

    function change_status($student_id){
      $student = Student::where('student_id', $student_id)->first();

      if ($student == null) {
          return redirect('/admin/student');
      }

      if ($student->is_active == 1) {
        $student->is_active = 0;
      }else {
        $student->is_active = 1;
      }

      $student->save();

      return redirect('/admin/student/')->withErrors(['Status changed!']);
    }

    function user_get_student($student_id){
      $student = Student::where('student_id', $student_id)->first();

      if ($student == null) {
          return redirect('/admin/student');
      }

      $student->get_students_section();
      $student->scores();

      //return $student;

      return view('teacher.student', ['student' => $student]);
    }


}
