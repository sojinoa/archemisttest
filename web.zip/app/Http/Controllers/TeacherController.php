<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\User;
use App\Teacher;
use App\Section;
use App\File;

class TeacherController extends Controller
{
    function add_teacher(Request $request){
       $this->validate($request, [
           'employee_id' => 'required|unique:teachers',
           'name' => 'required',
           'lastname' => 'required',
           'middlename' => 'required',
           'birthday' => 'required',
           'username' => 'required|unique:users',
       ]);

       $password = str_replace(',', '', str_replace(' ', '', $request->input('birthday')));

       $user = new User();
       $user->name = $request->input('name');
       $user->username = $request->input('username');
       $user->password = bcrypt(strtolower($password));
       $user->lastname = $request->input('lastname');
       $user->middlename = $request->input('middlename');
       $user->position = 'teacher';
       $user->birthday = $request->input('birthday');

       $user->save();

       $teacher = new Teacher();
       $teacher->user_id = $user->id;
       $teacher->employee_id = $request->input('employee_id');

       $teacher->save();

       return redirect('/admin/teacher')->withErrors(['Success!']);
    }

    function get_teacher($employee_id){
        $teacher = Teacher::where('employee_id', $employee_id)->first();

        if ($teacher == null) {
            return redirect('/admin/teacher');
        }

        $user = User::where('id', $teacher->user_id)->first();

        if ($user == null) {
            return redirect('/admin/teacher');
        }

        $files = File::where('user_id', $teacher->user_id)->get();

        $user->get_teacher_info();
        $user->get_teachers_sections($teacher->id);

        $available_sections = Section::where('teacher_id', -1)->where('is_active', 1)->get();

        return view('admin.teacher_profile', ['teacher' => $user, 'available_sections' => $available_sections, 'files' => $files]);;
    }

    function add_section_to_teacher($employee_id, $section_id){
        $section = Section::where('id', $section_id)->first();

        if ($section == null) {
            return redirect('/admin/teacher/'.$employee_id);
        }

        if ($section->teacher_id != -1) {
            return redirect('/admin/teacher/'.$employee_id);
        }

        $teacher = Teacher::where('employee_id', $employee_id)->first();
        if ($teacher == null) {
            return redirect('/admin/teacher/'.$employee_id);
        }

        $section->teacher_id = $teacher->id;
        $section->save();
        return redirect('/admin/teacher/'.$employee_id . '/sections')->withErrors(['Success!']);;
    }

    function edit_teacher(Request $request, $employee_id){
        $this->validate($request, [
            'password' => 'required|min:6|confirmed',
        ]);

        $teacher = Teacher::where('employee_id', $employee_id)->first();

        if ($teacher == null) {
            return redirect('/admin/teacher');
        }

        $user = User::where('id', $teacher->user_id)->first();

        if ($user == null) {
            return redirect('/admin/teacher');
        }

        $user->password = bcrypt($request->input('password'));
        $user->save();

        return redirect('/admin/teacher/'.$employee_id)->withErrors(['Success!']);;
    }

    function delete_teacher($employee_id){
        $teacher = Teacher::where('employee_id', $employee_id)->first();

        if ($teacher == null) {
            return redirect('/admin/teacher');
        }

        $user = User::where('id', $teacher->user_id)->first();

        if ($user == null) {
            return redirect('/admin/teacher');
        }

        $sections = Section::where('teacher_id', $teacher->id)->get();

        foreach ($sections as $section) {
              $section->teacher_id = -1;
              $section->save();
        }

        if ($teacher->is_active == 1) {
          $teacher->is_active = 0;
        }else {
          $teacher->is_active = 1;
        }



        $teacher->save();

        return redirect('/admin/teacher/')->withErrors(['Status changed!']);;
    }

    function user_get_teacher(){
        $teacher = Teacher::where('user_id', Auth::user()->id)->first();
        $user = Auth::user();

        $files = File::where('user_id', Auth::user()->id)->get();

        $user->get_teacher_info();
        $user->get_teachers_sections($teacher->id);

        return view('teacher.home', ['teacher' => $user, 'files' => $files]);
    }

    function add_file(Request $request, $stage){
      $this->validate($request, [
          'name' => 'required',
          'file' => 'required',
      ]);

      $document = $request->file('file');
      $file_name = time().'.'.$document->getClientOriginalName();
      $request->file->move('files', $file_name);

      $file = new File();
      $file->name = $request->input('name');
      $file->file = $file_name;
      $file->stage = $stage;
      $file->user_id = Auth::user()->id;

      $file->save();

      return redirect('/teacher/files/' . $stage)->withErrors(['Success!']);;

    }

    function user_sections(){
        $teacher = Teacher::where('user_id', Auth::user()->id)->first();
        $user = Auth::user();

        $user->get_teacher_info();
        $user->get_teachers_sections($teacher->id);

        return view('teacher.section', ['teacher' => $user]);
    }

    function user_files($stage){
        if (!is_numeric($stage)) {
            return redirect('/teacher/files')->withErrors(['Invalid stage!']);
        }

        if ($stage > 5) {
            return redirect('/teacher/files')->withErrors(['Invalid stage!']);
        }

        $teacher = Teacher::where('user_id', Auth::user()->id)->first();
        $user = Auth::user();

        $files = File::where('user_id', Auth::user()->id)
                      ->where('stage', $stage)
                      ->get();

        $user->get_teacher_info();
        $user->get_teachers_sections($teacher->id);

        return view('teacher.files', ['teacher' => $user, 'files' => $files, 'stage' => $stage]);
    }

    function file_stages(){
        return view('teacher.file_stages');
    }

    function user_quizzes(){
        return view('teacher.quizzes');
    }

    function get_teacher_sections($employee_id){
        $teacher = Teacher::where('employee_id', $employee_id)->first();

        if ($teacher == null) {
            return redirect('/admin/teacher');
        }

        $user = User::where('id', $teacher->user_id)->first();

        if ($user == null) {
            return redirect('/admin/teacher');
        }

        $files = File::where('user_id', $teacher->user_id)->get();

        $user->get_teacher_info();
        $user->get_teachers_sections($teacher->id);

        $available_sections = Section::where('teacher_id', -1)->where('is_active', 1)->get();

        return view('admin.teacher_profile_sections', ['teacher' => $user, 'available_sections' => $available_sections, 'files' => $files]);;
    }

    function display_teacher_stages_files($employee_id){
      $teacher = Teacher::where('employee_id', $employee_id)->first();

      if ($teacher == null) {
          return redirect('/admin/teacher');
      }

      $user = User::where('id', $teacher->user_id)->first();

      if ($user == null) {
          return redirect('/admin/teacher');
      }

      $files = File::where('user_id', $teacher->user_id)->get();

      $user->get_teacher_info();
      $user->get_teachers_sections($teacher->id);

      $available_sections = Section::where('teacher_id', -1)->where('is_active', 1)->get();

      return view('admin.teacher_profile_files', ['teacher' => $user, 'available_sections' => $available_sections, 'files' => $files]);;
    }

    function display_teacher_files($employee_id, $stage){
      if (!is_numeric($stage)) {
          return redirect('/admin/teacher');
      }

      if ($stage > 5) {
          return redirect('/admin/teacher');
      }

      $teacher = Teacher::where('employee_id', $employee_id)->first();

      if ($teacher == null) {
          return redirect('/admin/teacher');
      }

      $user = User::where('id', $teacher->user_id)->first();

      if ($user == null) {
          return redirect('/admin/teacher');
      }

      $files = File::where('user_id', $teacher->user_id)
                    ->where('stage', $stage)->get();

      $user->get_teacher_info();
      $user->get_teachers_sections($teacher->id);

      $available_sections = Section::where('teacher_id', -1)->where('is_active', 1)->get();

      return view('admin.teacher_profile_file', ['teacher' => $user, 'available_sections' => $available_sections, 'files' => $files, 'stage' => $stage]);;
    }

    function display_teacher_stages_quizzes($employee_id){
      $teacher = Teacher::where('employee_id', $employee_id)->first();

      if ($teacher == null) {
          return redirect('/admin/teacher');
      }

      $user = User::where('id', $teacher->user_id)->first();

      if ($user == null) {
          return redirect('/admin/teacher');
      }

      $files = File::where('user_id', $teacher->user_id)->get();

      $user->get_teacher_info();
      $user->get_teachers_sections($teacher->id);

      $available_sections = Section::where('teacher_id', -1)->where('is_active', 1)->get();

      return view('admin.teacher_profile_quizzes', ['teacher' => $user, 'available_sections' => $available_sections, 'files' => $files]);;
    }

}
