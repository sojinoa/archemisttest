<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\ChapterLesson;

class ChapterLessonController extends Controller
{
    function get_chapter_lesson($stage){
        $lesson = ChapterLesson::where('stage', $stage)->first();

        if ($lesson == null) {
              return redirect('cluster/stages');
        }

        return view('cluster.chapter_lesson', ['stage' => $stage, 'lesson' => $lesson]);
    }

    function edit_lesson(Request $request, $stage){
      $this->validate($request, [
          'title' => 'required',
          'content' => 'required',
      ]);

      $lesson = ChapterLesson::where('stage', $stage)->first();

      if ($lesson == null) {
            return redirect('cluster/stages');
      }

      $lesson->title = $request->input('title');
      $lesson->content = $request->input('content');
      $lesson->save();

      return redirect('cluster/chapterlesson/' . $stage)->withErrors(['Chapter lesson updated!']);;
    }
}
