<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use App\Student;
use App\Score;
use App\ChapterLesson;
use App\Question;
use App\Section;
use App\Teacher;
use App\User;
use App\File;

class ApiController extends Controller
{
    function login(Request $request){
        if (!$request->has('username')) {
          return response()->json([
            'error' => 'You must supply a username'
          ]);
        }

        $student = Student::where('student_id', $request->input('username'))->first();

        if ($student == null) {
          return response()->json([
            'error' => 'Invalid credentials'
          ]);
        }

        if (Hash::check($request->input('password'), $student->password)) {

              if ($student->is_confirmed == 0) {
                return response()->json([
                  'error' => 'Account not confirmed'
                ]);
              }

              if ($student->is_active == 0) {
                return response()->json([
                  'error' => 'Your account is inactive'
                ]);
              }

              if ($student->section_id == -1) {
                return response()->json([
                  'error' => 'There is no section associated with your account'
                ]);
              }

              $student->stage();
              $student->get_students_section();

              $student->high_scores();
              return $student;
        }

        return response()->json([
          'error' => 'Invalid credentials'
        ]);
    }

    function get_previous_scores($student_id, $stage){
        $scores = Score::where('student_id', $student_id)
                       ->where('stage', $stage)
                       ->orderBy('score', 'desc')->paginate(100);

        return $scores->toJson();
    }

    function get_chapter_lesson($stage){
        $chapterLesson = ChapterLesson::where('stage', $stage)->first();

        return $chapterLesson->toJson();
    }

    function get_random_questions($stage, $student_id){
        $student = Student::where('student_id',$student_id)->first();
        if ($student == null) {
            return null;
        }
        $section = Section::where('id', $student->section_id)->first();
        if ($section == null) {
            return null;
        }

        $teacher = Teacher::where('id', $section->teacher_id)->first();

        if ($teacher == null) {
            return null;
        }

        $records_count = Question::where('level', $stage)->count();

        if ($records_count == 0){
            return null;
        }
        if ($records_count < 10) {
          $questions = Question::where('level', $stage)->inRandomOrder()->paginate($records_count);


           return $questions;
        }

       $questions = Question::where('level', $stage)->inRandomOrder()->paginate(15);

       return $questions;
    }

    function get_teacher_files($student_id, $stage){
          $student = Student::where('student_id',$student_id)->first();

          $section = Section::where('id', $student->section_id)->first();

          $teacher = Teacher::where('id', $section->teacher_id)->first();

          $file = File::where('user_id', $teacher->user_id)
                      ->where('stage', $stage)
                      ->paginate(100);
          return $file;
    }

    function set_score(Request $request, $student_id, $stage){
        $score = new Score();
        $score->student_id = $student_id;
        $score->stage = $stage;
        $score->score = $request->input('score');

        $score->save();

        $student = Student::where('student_id', $student_id)->first();
        $student->stage();
        $student->get_students_section();
        $student->high_scores();

        return response()->json([
            'score' => Score::where('student_id', $student_id)
                           ->where('stage', $stage)
                           ->orderBy('id', 'desc')->paginate(100),
            'stage' => $student->stage,
            'high_score_one' => $student->high_score_one,
            'high_score_two' => $student->high_score_two,
            'high_score_three' => $student->high_score_three,
            'high_score_four' => $student->high_score_four,
            'high_score_five' => $student->high_score_five,
        ]);
    }

    function reload_student($student_id){
        $student = Student::where('student_id', $student_id)->first();

        if ($student == null) {
          return response()->json([
            'error' => 'Invalid credentials'
          ]);
        }

        if ($student->is_active == 0) {
          return response()->json([
            'error' => 'Your account is inactive'
          ]);
        }

        if ($student->section_id == -1) {
          return response()->json([
            'error' => 'There is no section associated with your account'
          ]);
        }

        $student->stage();
        $student->get_students_section();

        $student->high_scores();
        return $student;
    }
}
