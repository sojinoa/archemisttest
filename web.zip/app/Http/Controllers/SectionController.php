<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Section;
use App\Student;
use App\Teacher;

class SectionController extends Controller
{
    function add_section(Request $request){
      $this->validate($request, [
          'name' => 'required|unique:sections',
          'grade_level' => 'required|numeric',
      ]);

      $section = new Section();
      $section->name = $request->input('name');
      $section->grade_level = $request->input('grade_level');
      $section->teacher_id = -1;

      $section->save();
      return redirect('/admin/section')->withErrors(['Success!']);
    }

    function get_section($section_id){
        $section = Section::where('id', $section_id)->first();

        if ($section == null) {
            return redirect('/admin/section');
        }

        $students = Student::where('section_id', $section->id)
                            ->where('is_active', 1)
                            ->orderBy('lastname', 'asc')
                            ->get();
        $section->get_teacher_info();

        return view('admin.section_students', ['students' => $students, 'section' => $section]);
    }

    function edit_section(Request $request, $section_id){
        $this->validate($request, [
            'name' => 'required',
            'grade_level' => 'required',
        ]);

        $section = Section::where('id', $section_id)->first();

        if ($section == null) {
            return redirect('/admin/section');
        }

        $section->grade_level = $request->input('grade_level');
        $section->name = $request->input('name');

        $section->save();

        return redirect('/admin/section/' . $section->id)->withErrors(['Success!']);
    }

    function delete_section($section_id){
        $section = Section::where('id', $section_id)->first();

        if ($section == null) {
            return redirect('/admin/section');
        }

        $students = Student::where('section_id', $section->id)->get();

        foreach ($students as $student) {
            // $student->section_id = "-1";
             $student->section_id = -1;
             $student->is_confirmed = 0;
             $student->save();
            //$student->delete();
        }

        //$section->delete();
        if ($section->is_active == 1) {
          $section->is_active = 0;
          $section->teacher_id = -1;
        }else {
          $section->is_active = 1;
        }

        $section->save();

        return redirect('/admin/section')->withErrors(['Status updated!']);
    }

    function remove_section_from_teach($section_id){
        $section = Section::where('id', $section_id)->first();

        if ($section == null) {
            return redirect('/admin/section');
        }

        $teacher = Teacher::where('id', $section->teacher_id)->first();

        $section->teacher_id = -1;
        $section->save();

        return redirect('/admin/teacher/'.$teacher->employee_id . '/sections')->withErrors(['Section removed!']);;
    }

    function remove_student_from_section($section_id, $student_id){
      $section = Section::where('id', $section_id)->first();

      if ($section == null) {
          return redirect('/admin/section');
      }

      $student = Student::where('student_id', $student_id)->first();

      $student->section_id = -1;
      $student->is_confirmed = 0;
      $student->save();

      return redirect('/admin/section/' . $section->id)->withErrors(['Student removed!']);;
    }

    function user_get_section($section_id){
        $section = Section::where('id', $section_id)->first();

        if ($section == null) {
            return redirect('/teacher');
        }

        $students = Student::where('section_id', $section->id)
                            ->where('is_active', 1)
                            ->orderBy('lastname', 'asc')
                            ->get();
        $section->get_teacher_info();

        return view('teacher.section_students', ['students' => $students, 'section' => $section]);
    }

    function add_student_to_section(Request $request, $student_id){
        $this->validate($request, [
            'section_id' => 'required',
        ]);

        $section = Section::where('id', $request->input('section_id'))->first();
        if ($section == null) {
            return redirect('/admin/student');
        }

        $student = Student::where('student_id', $student_id)->first();
        if ($student == null) {
            return redirect('/admin/student');
        }

        $student->section_id = $section->id;
        $student->save();

        return redirect('/admin/student')->withErrors(['Student added!']);;
    }
}
