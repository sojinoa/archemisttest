<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\ChapterLesson;

use App\User;
use App\Element;

class ClusterController extends Controller
{
    function index(){
        return view('cluster.home');
    }

    function stages(){
        return view('cluster.stages');
    }

    function admin_stages(){
        return view('admin.cluster_stages');
    }

    function admin_get_chapter_lesson($stage){
        $lesson = ChapterLesson::where('stage', $stage)->first();

        if ($lesson == null) {
              return redirect('cluster/stages');
        }
        return view('admin.chapter_lesson', ['stage' => $stage, 'lesson' => $lesson]);
    }

    function admin_change_password(Request $request){
          $this->validate($request, [
              'password' => 'required|min:6|confirmed',
          ]);

          $cluster = User::where('position', 'cluster')->first();

          $cluster->password = bcrypt($request->input('password'));
          $cluster->save();

          return redirect('/admin/cluster')->withErrors(['Success!']);
    }

    function periodictable(){
        $elements = Element::all();

        return view('cluster.periodictable', ['elements' => $elements]);
    }
}
