<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Section extends Model
{
    public function get_teacher_info(){
        $teacher = Teacher::where('id', $this->teacher_id)->first();
        if ($teacher == null) {
            $this->attributes['teacher_info'] = null;
        }else{
          $this->attributes['teacher_info'] = User::where('id', $teacher->user_id)->first();
        }
    }
}
