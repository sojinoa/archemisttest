<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    public function get_students_section(){
        $this->attributes['section'] = Section::where('id', $this->section_id)->first();
    }

    public function high_scores(){
      $this->attributes['high_score_one'] = 0;
      $this->attributes['high_score_two'] = 0;
      $this->attributes['high_score_three'] = 0;
      $this->attributes['high_score_four'] = 0;
      $this->attributes['high_score_five'] = 0;

      $stageOne = Score::where('student_id', $this->student_id)
                       ->where('stage', 1)
                       ->orderBy('score', 'desc')->first();

      if ($stageOne != null) {
          $this->attributes['high_score_one'] = $stageOne->score;
      }

      $stageTwo = Score::where('student_id', $this->student_id)
                       ->where('stage', 2)
                       ->orderBy('score', 'desc')->first();

      if ($stageTwo != null) {
          $this->attributes['high_score_one'] = $stageTwo->score;
      }

      $stageThree = Score::where('student_id', $this->student_id)
                       ->where('stage', 3)
                       ->orderBy('score', 'desc')->first();

      if ($stageThree != null) {
          $this->attributes['high_score_one'] = $stageThree->score;
      }

      $stageFour = Score::where('student_id', $this->student_id)
                       ->where('stage', 4)
                       ->orderBy('score', 'desc')->first();

      if ($stageFour != null) {
          $this->attributes['high_score_one'] = $stageFour->score;
      }

      $stageFive = Score::where('student_id', $this->student_id)
                       ->where('stage', 5)
                       ->orderBy('score', 'desc')->first();

      if ($stageFive != null) {
          $this->attributes['high_score_one'] = $stageFive->score;
      }

    }

    public function stage(){
        $this->attributes['stage'] = 1;

        $stageOne = Score::where('student_id', $this->student_id)
                         ->where('stage', 1)
                         ->where('score', '>', 19)->first();

        if ($stageOne != null) {
            $this->attributes['stage'] = 2;
        }

        $stageOne = Score::where('student_id', $this->student_id)
                         ->where('stage', 2)
                         ->where('score', '>', 29)->first();

        if ($stageOne != null) {
            $this->attributes['stage'] = 3;
        }

        $stageOne = Score::where('student_id', $this->student_id)
                         ->where('stage', 3)
                         ->where('score', '>', 49)->first();

        if ($stageOne != null) {
            $this->attributes['stage'] = 4;
        }

        $stageOne = Score::where('student_id', $this->student_id)
                         ->where('stage', 4)
                         ->where('score', '>', 69)->first();

        if ($stageOne != null) {
            $this->attributes['stage'] = 5;
        }
    }

    public function scores(){
      $stageOne = Score::where('student_id', $this->student_id)
                       ->where('stage', 1)->get();

      $stageTwo = Score::where('student_id', $this->student_id)
                      ->where('stage', 2)->get();

      $stageThree = Score::where('student_id', $this->student_id)
                      ->where('stage', 3)->get();

      $stageFour = Score::where('student_id', $this->student_id)
                      ->where('stage', 4)->get();

      $stageFive = Score::where('student_id', $this->student_id)
                   ->where('stage', 5)->get();

      $this->attributes['scores_one'] = $stageOne;
      $this->attributes['scores_two'] = $stageTwo;
      $this->attributes['scores_three'] = $stageThree;
      $this->attributes['scores_four'] = $stageFour;
      $this->attributes['scores_five'] = $stageFive;
    }
}
