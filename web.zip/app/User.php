<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

use App\Teacher;
use App\Section;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'username', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function get_teacher_info(){
      $this->attributes['teacher_info'] = Teacher::where('user_id', $this->id)->first();
    }

    public function get_teachers_sections($teacher_id){
        $this->attributes['sections'] = Section::where('teacher_id', $teacher_id)->get();
    }
}
