<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateElementsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
      Schema::create('elements', function (Blueprint $table) {
          $table->increments('id');
          $table->integer('atomic_number')->unsigned();
          $table->string('name');
          $table->string('symbol');
          $table->string('group');
          $table->string('block');
          $table->string('period');
          $table->string('atomic_weight');
          $table->string('discoverer');
          $table->string('year_discovered');
          $table->string('electron_configuration');
          $table->string('oxidation_state');
          $table->string('ionic_charge');
          $table->longText('uses');
          $table->timestamps();
      });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('elements');
    }
}
