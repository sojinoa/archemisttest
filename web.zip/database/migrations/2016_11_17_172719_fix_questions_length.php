<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class FixQuestionsLength extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
      Schema::table('questions', function($table) {
        $table->longText('title')->change();
        $table->longText('choice_1')->change();
        $table->longText('choice_2')->change();
        $table->longText('choice_3')->change();
        $table->longText('choice_4')->change();
    });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
