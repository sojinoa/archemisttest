<?php

use Illuminate\Database\Seeder;

class ChapterLessonSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('chapter_lessons')->insert([
          'title' => 'Stage 1',
          'stage' => 1,
          'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sed risus ex. Aliquam rhoncus, urna placerat elementum suscipit, ligula elit maximus quam, non fermentum ipsum libero in ligula. Aliquam feugiat fringilla ipsum, id tempor lorem. Quisque quis dui ultrices, porttitor libero et, facilisis elit. Mauris lacus nisl, fermentum nec dictum vel, laoreet ac velit. Nunc justo eros, ornare in accumsan nec, sollicitudin sit amet massa. Nullam imperdiet semper ante, sit amet suscipit erat. Nunc varius, tellus ut dapibus finibus, tortor diam luctus dolor, eu congue augue orci quis massa. Aliquam sed pellentesque tellus. Aliquam erat volutpat. Mauris et mollis velit. Etiam a ullamcorper eros. Integer eu velit neque. Nunc orci lacus, interdum pulvinar velit id, ultrices commodo felis.'
      ]);

      DB::table('chapter_lessons')->insert([
          'title' => 'Stage 2',
          'stage' => 2,
          'content' => 'Proin vitae massa quis diam convallis pharetra. Fusce egestas porttitor neque, vitae blandit metus scelerisque nec. Cras interdum turpis sagittis eros condimentum, eu interdum felis tempus. In egestas laoreet dui vehicula vehicula. Aliquam vel efficitur odio, sit amet porta ante. Curabitur maximus condimentum nibh, ut fringilla elit. Nulla quis risus et justo scelerisque aliquet. Nam non felis lobortis, sollicitudin mauris sit amet, hendrerit tortor. Curabitur turpis enim, mattis in vulputate ac, finibus et leo. Donec a iaculis sapien. Duis turpis erat, volutpat quis risus egestas, consequat viverra lectus. Maecenas vestibulum vel arcu ut hendrerit. Nunc rutrum nisi eu eros malesuada bibendum. Cras facilisis dolor id odio fermentum maximus. Duis nunc urna, fringilla a ultrices efficitur, pharetra tempus orci.'
      ]);

      DB::table('chapter_lessons')->insert([
          'title' => 'Stage 3',
          'stage' => 3,
          'content' => 'Cras ut sem nulla. Vivamus nec tellus volutpat nunc aliquet pulvinar. In hac habitasse platea dictumst. Nullam id justo non ante pellentesque vestibulum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam sed urna ut elit tempor viverra molestie sit amet massa. Fusce venenatis neque vitae est eleifend laoreet. Praesent sagittis augue efficitur lectus scelerisque, sed ultrices augue porttitor. Morbi ligula sem, imperdiet bibendum enim in, consequat egestas felis. Cras nec neque in urna faucibus sagittis. Aenean id leo fringilla, cursus ligula nec, ultricies sapien. Curabitur malesuada ut tellus in dapibus. Nunc posuere faucibus ipsum, malesuada molestie nunc vestibulum et. Vestibulum in enim lacus. Aenean libero augue, lobortis non ante eu, faucibus cursus ex.'
      ]);

      DB::table('chapter_lessons')->insert([
          'title' => 'Stage 4',
          'stage' => 4,
          'content' => 'Integer eleifend interdum tortor at elementum. Ut ut quam tincidunt, dictum dolor in, venenatis urna. Pellentesque felis lectus, sollicitudin nec dictum non, sollicitudin nec elit. Curabitur venenatis, odio non varius egestas, nisi dui consequat leo, nec pellentesque ante enim a arcu. In sed mi ac justo lobortis ullamcorper ut eu ipsum. Etiam sit amet leo suscipit, cursus mi et, porttitor nibh. Vivamus ullamcorper mi orci, ornare pellentesque est gravida vitae. Integer in faucibus ligula, et mattis erat. Morbi rutrum, neque non suscipit gravida, enim enim suscipit justo, vel imperdiet lectus lectus nec ligula. Praesent nec sapien quis elit aliquam tempus. Quisque lobortis tortor urna, ac aliquam enim molestie auctor.'
      ]);

      DB::table('chapter_lessons')->insert([
          'title' => 'Stage 5',
          'stage' => 5,
          'content' => 'Suspendisse diam enim, feugiat sit amet risus vel, blandit lacinia leo. Ut porta vitae turpis non euismod. Phasellus aliquet, est a tincidunt varius, massa nisi molestie tortor, ut tristique sapien ipsum sit amet orci. Ut tincidunt leo eget pretium congue. Curabitur ut mauris eget massa rhoncus maximus non sit amet magna. Nam a urna eu nulla rutrum auctor. Aliquam erat volutpat. Integer vulputate sodales eleifend.'
      ]);
    }
}
