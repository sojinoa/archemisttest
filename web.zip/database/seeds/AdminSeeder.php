<?php

use Illuminate\Database\Seeder;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('users')->insert([
          'name' => "Admin",
          'username' => 'admin',
          'lastname' => 'admin',
          'middlename' => 'admin',
          'password' => bcrypt('password'),
          'position' => 'admin',
          'birthday' => '14 November, 1994'
      ]);

      // DB::table('users')->insert([
      //     'name' => "Teacher One",
      //     'username' => 'teacher_one',
      //     'password' => bcrypt('password'),
      //     'position' => 'teacher',
      // ]);
      //
      // DB::table('users')->insert([
      //     'name' => "Cluster One",
      //     'username' => 'cluster_one',
      //     'password' => bcrypt('password'),
      //     'position' => 'cluster',
      // ]);
    }
}
