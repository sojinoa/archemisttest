<?php

use Illuminate\Database\Seeder;

class score_seeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('scores')->insert([
          'student_id' => "143",
          'score' => '5',
          'stage' => 1
      ]);

      DB::table('scores')->insert([
          'student_id' => "143",
          'score' => '8',
          'stage' => 1
      ]);

      DB::table('scores')->insert([
          'student_id' => "143",
          'score' => '7',
          'stage' => 2
      ]);

      DB::table('scores')->insert([
          'student_id' => "143",
          'score' => '8',
          'stage' => 2
      ]);

      DB::table('scores')->insert([
          'student_id' => "143",
          'score' => '5',
          'stage' => 2
      ]);
    }
}
