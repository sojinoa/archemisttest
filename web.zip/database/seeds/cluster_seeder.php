<?php

use Illuminate\Database\Seeder;

class cluster_seeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('users')->insert([
          'name' => "Cluster",
          'lastname' => 'Lastname',
          'middlename' => 'Firstname',
          'username' => 'cluster',
          'password' => bcrypt('password'),
          'position' => 'cluster',
          'birthday' => '14 November, 1994'
      ]);
    }
}
