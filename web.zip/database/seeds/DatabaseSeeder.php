<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         $this->call(ChapterLessonSeeder::class);
         $this->call(AdminSeeder::class);
         $this->call(cluster_seeder::class);
         $this->call(ElementsSeeder::class);

        //$this->call(score_seeder::class);
    }
}
