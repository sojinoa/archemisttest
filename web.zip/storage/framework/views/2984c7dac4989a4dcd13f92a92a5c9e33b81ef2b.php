<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link rel="shortcut icon" href="<?php echo e(asset('fav_ico.png')); ?>">

        <title>Archemist - 404</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">
        <!-- Compiled and minified CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/css/materialize.min.css">

        <style>
            html {
                height: 100%;
            }

            body {
                min-height: 100%;
            }

            .full {
                width: 100%;
                height: 100%;
            }

            p {
              margin: 0px;
            }

            h2 {
              margin: 5px;
            }

        </style>

    </head>
    <body class="full">
      <div class="valign-wrapper" style="height:100%; width:100%;">
          <div class="valign" style="width:inherit">
              <h2 class="center-align">
                404
              </h2>
              <p class="center-align">
                <strong>Archemist</strong>
              </p>
          </div>
      </div>
      </div>
    </body>
</html>
