<html>
    <head>
      <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../../css/materialize.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

      <title><?php echo e(config('app.name')); ?> - <?php echo e($student->name); ?></title>
      <link rel="shortcut icon" type="image/png" href="../../images/favico.png"/>


    </head>

    <body class="grey lighten-3">
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="../../js/bin/materialize.js"></script>

      <script>
          $( document ).ready(function() {
              $(".dropdown-button").dropdown();
              $('.modal').modal();
          });
      </script>

      <ul id="dropdown1" class="dropdown-content">
        <li><a href="#modal_account" ><?php echo e(Auth::user()->name); ?></a></li>
        <li><a href="<?php echo e(url('/logout')); ?>"
            onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();">
            Logout
        </a>

        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form></li>
      </ul>

      <div class="navbar-fixed">
      <nav>
        <div class="nav-wrapper">
          <a href="../../admin" class="brand-logo"><?php echo e(config('app.name')); ?></a>
          <ul class="right">
            <li><a class="dropdown-button" href="#!" data-activates="dropdown1"><?php echo e(Auth::user()->name); ?><i class="material-icons right">arrow_drop_down</i></a></li>
          </ul>
        </div>
      </nav>
    </div>
  </br>
    <div class="container">
      <nav class="grey lighten-3" style="    box-shadow: none;">
        <div class="nav-wrapper">
          <div class="col s12">
            <a href="../../teacher" class="breadcrumb grey-text">Home</a>
            <a href="../sections" class="breadcrumb grey-text">Sections</a>
            <a href="../../teacher/section/<?php echo e($student->section->id); ?>" class="breadcrumb grey-text"><?php echo e($student->section->grade_level); ?> - <?php echo e($student->section->name); ?></a>
            <a href="#" class="breadcrumb black-text"><?php echo e($student->lastname); ?>, <?php echo e($student->name); ?></a>
          </div>
        </div>
      </nav>

    </br></br>
      <div class="black-text menu-item" style="font-size: 20px;"><?php echo e($student->lastname); ?>, <?php echo e($student->name); ?> <?php echo e($student->middlename); ?></div>
      <div class="black-text sub-menu-item"><b>Student ID:</b> <?php echo e($student->student_id); ?></div>
      <div class="black-text sub-menu-item"><b>Birthday:</b> <?php echo e($student->birthday); ?></div>
      </br>

      <div class="row">

        <a href="#modal_score_1">
          <div class="col s12 m4">
            <div class="card small white waves-effect">
              <div class="valign-wrapper " style="height: 100%">
                  <div class="valign" style="width:100%">

                    <div class="center-align">
                        <img src="../../images/1.png"/>
                        <div class="black-text menu-item">Covalent Bonding</div>
                    </div>

                  </div>
              </div>
            </div>
          </div>
        </a>

        <a href="#modal_score_2">
          <div class="col s12 m4">
            <div class="card small white waves-effect">
              <div class="valign-wrapper " style="height: 100%">
                  <div class="valign" style="width:100%">

                    <div class="center-align">
                        <img src="../../images/2.png"/>
                        <div class="black-text menu-item">Polar Covalent Bonding</div>
                    </div>

                  </div>
              </div>
            </div>
          </div>
        </a>

        <a href="#modal_score_3">
          <div class="col s12 m4">
            <div class="card small white waves-effect">
              <div class="valign-wrapper " style="height: 100%">
                  <div class="valign" style="width:100%">

                    <div class="center-align">
                        <img src="../../images/3.png"/>
                        <div class="black-text menu-item">Ionic Bonding</div>
                    </div>

                  </div>
              </div>
            </div>
          </div>
        </a>

        <a href="#modal_score_4">
          <div class="col s12 m4">
            <div class="card small white waves-effect">
              <div class="valign-wrapper " style="height: 100%">
                  <div class="valign" style="width:100%">

                    <div class="center-align">
                        <img src="../../images/4.png"/>
                        <div class="black-text menu-item">Metallic Bonding</div>
                    </div>

                  </div>
              </div>
            </div>
          </div>
        </a>

        <a href="#modal_score_5">
          <div class="col s12 m4">
            <div class="card small white waves-effect">
              <div class="valign-wrapper " style="height: 100%">
                  <div class="valign" style="width:100%">

                    <div class="center-align">
                        <img src="../../images/5.png"/>
                        <div class="black-text menu-item">Hydrogen Bonding</div>
                    </div>

                  </div>
              </div>
            </div>
          </div>
        </a>

      </div>




      <div id="modal_score_1" class="modal modal-fixed-footer">
        <div class="modal-content">
          <div class="black-text menu-item" style="font-size: 20px;">Covalent Bonding</div>
            <?php if(count($student->scores_one) > 0): ?>

              <table class="responsive-table striped">
                <thead>
                  <tr>
                      <th data-field="id">Date</th>
                      <th data-field="name">Score</th>
                  </tr>
                </thead>

                <tbody>

                  <?php $__currentLoopData = $student->scores_one; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                  <tr>
                    <td><?php echo e($score->updated_at); ?></td>
                    <td><?php echo e($score->score); ?></td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </tbody>
              </table>

            <?php else: ?>

              <div class="black-text sub-menu-item">No data available</div>

            <?php endif; ?>
        </div>
        <div class="modal-footer">
          <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat ">Dismiss</a>
        </div>
      </div>

      <div id="modal_score_2" class="modal modal-fixed-footer">
        <div class="modal-content">
          <div class="black-text menu-item" style="font-size: 20px;">Polar Covalent Bonding</div>
            <?php if(count($student->scores_two) > 0): ?>

              <table class="responsive-table striped">
                <thead>
                  <tr>
                      <th data-field="id">Date</th>
                      <th data-field="name">Score</th>
                  </tr>
                </thead>

                <tbody>

                  <?php $__currentLoopData = $student->scores_two; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                  <tr>
                    <td><?php echo e($score->updated_at); ?></td>
                    <td><?php echo e($score->score); ?></td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </tbody>
              </table>

            <?php else: ?>

              <div class="black-text sub-menu-item">No data available</div>

            <?php endif; ?>
        </div>
        <div class="modal-footer">
          <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat ">Dismiss</a>
        </div>
      </div>

      <div id="modal_score_3" class="modal modal-fixed-footer">
        <div class="modal-content">
          <div class="black-text menu-item" style="font-size: 20px;">Ionic Bonding</div>
            <?php if(count($student->scores_three) > 0): ?>

              <table class="responsive-table striped">
                <thead>
                  <tr>
                      <th data-field="id">Date</th>
                      <th data-field="name">Score</th>
                  </tr>
                </thead>

                <tbody>

                  <?php $__currentLoopData = $student->scores_three; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                  <tr>
                    <td><?php echo e($score->updated_at); ?></td>
                    <td><?php echo e($score->score); ?></td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </tbody>
              </table>

            <?php else: ?>

              <div class="black-text sub-menu-item">No data available</div>

            <?php endif; ?>
        </div>
        <div class="modal-footer">
          <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat ">Dismiss</a>
        </div>
      </div>

      <div id="modal_score_4" class="modal modal-fixed-footer">
        <div class="modal-content">
          <div class="black-text menu-item" style="font-size: 20px;">Metallic Bonding</div>
            <?php if(count($student->scores_four) > 0): ?>

              <table class="responsive-table striped">
                <thead>
                  <tr>
                      <th data-field="id">Date</th>
                      <th data-field="name">Score</th>
                  </tr>
                </thead>

                <tbody>

                  <?php $__currentLoopData = $student->scores_four; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                  <tr>
                    <td><?php echo e($score->updated_at); ?></td>
                    <td><?php echo e($score->score); ?></td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </tbody>
              </table>

            <?php else: ?>

              <div class="black-text sub-menu-item">No data available</div>

            <?php endif; ?>
        </div>
        <div class="modal-footer">
          <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat ">Dismiss</a>
        </div>
      </div>

      <div id="modal_score_5" class="modal modal-fixed-footer">
        <div class="modal-content">
          <div class="black-text menu-item" style="font-size: 20px;">Hydrogen Bonding</div>
            <?php if(count($student->scores_five) > 0): ?>

              <table class="responsive-table striped">
                <thead>
                  <tr>
                      <th data-field="id">Date</th>
                      <th data-field="name">Score</th>
                  </tr>
                </thead>

                <tbody>

                  <?php $__currentLoopData = $student->scores_five; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                  <tr>
                    <td><?php echo e($score->updated_at); ?></td>
                    <td><?php echo e($score->score); ?></td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </tbody>
              </table>

            <?php else: ?>

              <div class="black-text sub-menu-item">No data available</div>

            <?php endif; ?>
        </div>
        <div class="modal-footer">
          <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat ">Dismiss</a>
        </div>
      </div>

    </br>

    </body>
  </html>
