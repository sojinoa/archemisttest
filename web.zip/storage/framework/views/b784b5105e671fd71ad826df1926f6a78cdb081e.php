<html>
    <head>
      <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../../../css/materialize.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

      <title><?php echo e(config('app.name')); ?> - Chapter Lesson</title>
      <link rel="shortcut icon" type="image/png" href="../../../images/favico.png"/>


    </head>

    <body class="grey lighten-3">
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="../../../js/bin/materialize.js"></script>

      <script>
          $( document ).ready(function() {
              $(".dropdown-button").dropdown();
              $('.modal').modal();
          });
      </script>

      <ul id="dropdown1" class="dropdown-content">
        <li><a href="#modal_account" ><?php echo e(Auth::user()->name); ?></a></li>
        <li><a href="<?php echo e(url('/logout')); ?>"
            onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();">
            Logout
        </a>

        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form></li>
      </ul>

      <div class="navbar-fixed">
      <nav>
        <div class="nav-wrapper">
          <a href="" class="brand-logo"><?php echo e(config('app.name')); ?></a>
          <ul class="right">
            <li><a class="dropdown-button" href="#!" data-activates="dropdown1"><?php echo e(Auth::user()->name); ?><i class="material-icons right">arrow_drop_down</i></a></li>
          </ul>
        </div>
      </nav>
    </div>
  </br>
    <div class="container">
      <nav class="grey lighten-3" style="    box-shadow: none;">
        <div class="nav-wrapper">
          <div class="col s12">
            <a href="../../../admin" class="breadcrumb grey-text">Home</a>
            <a href="../../../admin/cluster" class="breadcrumb grey-text">Cluster</a>
            <a href="#" class="breadcrumb black-text"><?php echo e($lesson->title); ?></a>
          </div>
        </div>
      </nav>
      <div class="black-text menu-item" style="font-size: 20px;">
        <?php if($stage == 1): ?>
          Covalent Bonding
        <?php elseif($stage == 2): ?>
          Polar Covalent Bonding
        <?php elseif($stage == 3): ?>
          Ionic Bonding
        <?php elseif($stage == 4): ?>
          Metallic Bonding
        <?php elseif($stage == 5): ?>
          Hydrogen Bonding
        <?php endif; ?>
      </div>
      <div class="black-text sub-menu-item"><?php echo e($lesson->title); ?></div>
      </br>
      <div class="row">
        <div class="col s12">
        <div class="card-panel white">
          <?php echo nl2br( "<p class='sub-menu-item'>" . $lesson->content . '</p>', true); ?>
        </div>
      </div>


      </div>
    </div>

    </body>
  </html>
