<html>
    <head>
      <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../css/materialize.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

      <title><?php echo e(config('app.name')); ?> - Files</title>
      <link rel="shortcut icon" type="image/png" href="../images/favico.png"/>

    </head>

    <body class="grey lighten-3">
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="../js/bin/materialize.js"></script>

      <script>
          $( document ).ready(function() {
              $(".dropdown-button").dropdown();
              $('.modal').modal();
          });
      </script>

      <ul id="dropdown1" class="dropdown-content">
        <li><a href="#modal_account" ><?php echo e(Auth::user()->name); ?></a></li>
        <li><a href="<?php echo e(url('/logout')); ?>"
            onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();">
            Logout
        </a>

        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form></li>
      </ul>

      <div class="navbar-fixed">
      <nav>
        <div class="nav-wrapper">
          <a href="../admin" class="brand-logo"><?php echo e(config('app.name')); ?></a>
          <ul class="right">
            <li><a class="dropdown-button" href="#!" data-activates="dropdown1"><?php echo e(Auth::user()->name); ?><i class="material-icons right">arrow_drop_down</i></a></li>
          </ul>
        </div>
      </nav>
    </div>
  </br>
    <div class="container">
      <nav class="grey lighten-3" style="    box-shadow: none;">
        <div class="nav-wrapper">
          <div class="col s12">
            <a href="../teacher" class="breadcrumb grey-text">Home</a>
            <a href="#" class="breadcrumb black-text">Sections</a>
          </div>
        </div>
      </nav>
    </br></br>
    <div class="black-text menu-item">Sections</div>
      <div class="row">
        <?php if(count($errors) > 0): ?>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <script>
                Materialize.toast('<?php echo e($error); ?>', 3000, 'rounded');
              </script>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php endif; ?>

        <?php if(count($teacher->sections) > 0): ?>
          <?php $__currentLoopData = $teacher->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if($section->is_active == 1): ?>
              <a href="section/<?php echo e($section->id); ?>">
            <?php else: ?>
              <a href="#">
            <?php endif; ?>
                <div class="col s12 m4">
                  <div class="card small waves-effect <?php echo e(($section->is_active == 1) ? 'white' : 'grey lighten-2'); ?>">
                    <div class="valign-wrapper " style="height: 100%">
                        <div class="valign" style="width:100%">

                          <div class="center-align">
                              <img src="../images/star.png"/>
                              <div class="black-text menu-item"><?php echo e($section->grade_level); ?> <?php echo e($section->name); ?></div>
                          </div>

                        </div>
                    </div>
                  </div>
                </div>
              </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

          <?php else: ?>
          <div class="black-text sub-menu-item">No sections found</div>
        <?php endif; ?>
    </div>
    </div>
    </body>
  </html>
