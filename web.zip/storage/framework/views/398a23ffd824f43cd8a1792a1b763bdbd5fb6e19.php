<html>
    <head>
      <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../css/materialize.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

      <title><?php echo e(config('app.name')); ?> - Students</title>
      <link rel="shortcut icon" type="image/png" href="../images/favico.png"/>


    </head>

    <body class="grey lighten-3">
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="../js/bin/materialize.js"></script>

      <script>
          $( document ).ready(function() {
              $(".dropdown-button").dropdown();
              $('select').material_select();
              $('.modal').modal();
              $('.datepicker').pickadate({
                selectMonths: true, // Creates a dropdown to control month
                selectYears: 90 // Creates a dropdown of 15 years to control year
              });
          });
      </script>

      <ul id="dropdown1" class="dropdown-content">
        <li><a href="#modal_account" ><?php echo e(Auth::user()->name); ?></a></li>
        <li><a href="<?php echo e(url('/logout')); ?>"
            onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();">
            Logout
        </a>

        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form></li>
      </ul>

      <div class="navbar-fixed">
      <nav>
        <div class="nav-wrapper">
          <a href="../admin" class="brand-logo"><?php echo e(config('app.name')); ?></a>
          <ul class="right">
            <li><a class="dropdown-button" href="#!" data-activates="dropdown1"><?php echo e(Auth::user()->name); ?><i class="material-icons right">arrow_drop_down</i></a></li>
          </ul>
        </div>
      </nav>
    </div>
  </br>
    <div class="container">
      <nav class="grey lighten-3" style="    box-shadow: none;">
        <div class="nav-wrapper">
          <div class="col s12">
            <a href="../admin" class="breadcrumb grey-text">Home</a>
            <a href="#" class="breadcrumb black-text">Students</a>
          </div>
        </div>
      </nav>
    </br></br>
      <div class="row">
        <?php if(count($errors) > 0): ?>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <script>
                Materialize.toast('<?php echo e($error); ?>', 3000, 'rounded');
              </script>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php endif; ?>
        <a href="#add_section">
          <div class="col s12 m4">
            <div class="card small white waves-effect">
              <div class="valign-wrapper " style="height: 100%">
                  <div class="valign" style="width:100%">

                    <div class="center-align">
                        <img src="../images/add (1).png"/>
                      </br>
                        <div class="black-text menu-item">Add student</div>
                        <div class="grey-text submenu-item">Add a new student</div>
                    </div>

                  </div>
              </div>
            </div>
          </div>
        </a>

        <?php if(count($students) > 0): ?>
          <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <a>
                <div class="col s12 m4">
                  <div class="card small white waves-effect">
                    <div class="valign-wrapper " style="height: 100%">
                        <div class="valign" style="width:100%">

                          <div class="center-align">
                              <img src="../images/id-card.png"/>
                              </br>
                              <div class="black-text menu-item"><?php echo e($student->lastname); ?>, <?php echo e($student->name); ?></div>
                                <?php if($student->section != null): ?>
                                    <div class="black-text sub-menu-item">
                                        <?php echo e($student->section->grade_level); ?> - <?php echo e($student->section->name); ?>

                                        <?php if($student->is_confirmed == 0): ?>
                                        - Pending
                                        <?php endif; ?>
                                    </div>

                                <?php else: ?>
                                    <?php if($student->section_id == -69): ?>
                                    <div class="black-text sub-menu-item">
                                    - Declined
                                    </div>
                                    <?php endif; ?>

                                    <a href="#add_to_section_<?php echo e($student->id); ?>" class="waves-effect waves-light btn btn-flat">Set section</a>
                                    </br>
                                <?php endif; ?>
                              </br>
                              <?php if($student->is_active == 1): ?>
                                <a href="#modal_status_<?php echo e($student->id); ?>" class="waves-effect waves-light btn red lighten-1">Set as inactive</a>
                              <?php else: ?>
                                <a href="#modal_status_<?php echo e($student->id); ?>" class="waves-effect waves-light btn green lighten-1">Set as active</a>
                              <?php endif; ?>
                            <!-- </br>
                            </br>
                              <a href="#modal_remove_<?php echo e($student->id); ?>" class="waves-effect waves-light btn red lighten-1">Delete</a> -->
                          </div>

                        </div>
                    </div>
                  </div>
                </div>
              </a>

              <div id="modal_status_<?php echo e($student->id); ?>" class="modal">
                <div class="modal-content">
                  <span class="card-title menu-item">Change status</span>
                </br></br>
                  <div class="row">
                    <form class="col s12" action="../admin/student/changestatus/<?php echo e($student->student_id); ?>" method="POST">
                      <?php echo e(csrf_field()); ?>

                      <input type="hidden" name="_method" value="delete">
                      <p>Are you sure you want to change the status of student <?php echo e($student->name); ?>?</p>
                  </div>
                </div>
                <div class="modal-footer">
                  <button class="btn waves-effect waves-light red" type="submit" name="action">Change
                  </button>
                </div>
                </form>
              </div>


              <div id="add_to_section_<?php echo e($student->id); ?>" class="modal">
                <div class="modal-content">
                  <span class="card-title menu-item">Add to section</span>
                </br></br>
                  <div class="row">
                    <form class="col s12" action="../admin/sectionaddstudent/<?php echo e($student->student_id); ?>" method="POST">
                      <?php echo e(csrf_field()); ?>

                      <div class="input-field col s12">
                        <select name="section_id">
                          <option value="" disabled selected>Select section</option>
                          <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <option value="<?php echo e($section->id); ?>"><?php echo e($section->grade_level); ?> <?php echo e($section->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </select>
                        <label>Select section</label>
                      </div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button class="btn waves-effect waves-light" type="submit" name="action">ADD
                  </button>
                </div>
                </form>
              </div>

              <div id="modal_remove_<?php echo e($student->id); ?>" class="modal">
                <div class="modal-content">
                  <span class="card-title menu-item">Delete student</span>
                </br></br>
                  <div class="row">
                    <form class="col s12" action="../admin/student/delete/<?php echo e($student->student_id); ?>" method="POST">
                      <?php echo e(csrf_field()); ?>

                      <input type="hidden" name="_method" value="delete">
                      <p>Are you sure you want to delete student <?php echo e($student->name); ?>? This cannot be undone.</p>
                  </div>
                </div>
                <div class="modal-footer">
                  <button class="btn waves-effect waves-light red" type="submit" name="action">DELETE
                  </button>
                </div>
                </form>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php endif; ?>
    </div>
    </div>




    <div id="add_section" class="modal modal-fixed-footer">
        <div class="modal-content">
          <span class="card-title menu-item">Add new student</span>
        </br></br>
          <div class="row">
            <form class="col s12" action="../admin/student/add" method="POST">
              <?php echo e(csrf_field()); ?>

              <div class="row">
                <div class="input-field col s4">
                  <input id="student_id" name="student_id" type="text" class="validate" required>
                  <label for="grade_level">Student ID</label>
                </div>
              </div>
              <div class="row">
                <div class="input-field col s8">
                  <input id="name" type="text" name="name" class="validate" required>
                  <label for="name">First Name</label>
                </div>
              </div>
              <div class="row">
                <div class="input-field col s8">
                  <input id="lastname" type="text" name="lastname" class="validate" required>
                  <label for="name">Last Name</label>
                </div>
              </div>
              <div class="row">
                <div class="input-field col s8">
                  <input id="middlename" type="text" name="middlename" class="validate" required>
                  <label for="name">Middle Name</label>
                </div>
              </div>
              <div class="row">
                <div class="input-field col s8">
                  <input type="date" class="datepicker" name="birthday" value="<?php echo date("d F, Y"); ?>">
                  <label>Birthday</label>
                </div>
              </div>
              <div class="row">
                <div class="input-field col s12">
                  <select name="section_id">
                    <option value="" disabled selected>Choose section</option>
                    <?php if(count($sections) > 0): ?>
                      <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                          <option value="<?php echo e($section->id); ?>"><?php echo e($section->grade_level); ?> - <?php echo e($section->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php endif; ?>
                  </select>
                  <label>Section</label>
                </div>
              </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn waves-effect waves-light" type="submit" name="action">Add
          </button>
        </div>
        </form>
      </div>

      <?php if(count($sections) == 0): ?>
        <script>
        $(document).ready(function(){
          $('#no_data_modal').modal('open');

        });
        </script>

        <div id="no_data_modal" class="modal">
          <div class="modal-content">
            <span class="card-title menu-item">No sections available</span>
          </br></br>
            <p>There are no sections with teacher assigned available. Please add one.</p>
          </div>
          <div class="modal-footer">
            <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat ">Dismiss</a>
          </div>
        </div>
      <?php endif; ?>


    </body>
  </html>
