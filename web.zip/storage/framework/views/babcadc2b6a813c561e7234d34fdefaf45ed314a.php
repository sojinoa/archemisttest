<html>
    <head>
      <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../css/materialize.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

      <title><?php echo e(config('app.name')); ?> - Admin</title>
      <link rel="shortcut icon" type="image/png" href="../images/favico.png"/>

      <style>
        .small {
          width: 100%
        }
      </style>
    </head>

    <body class="grey lighten-3">
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="../js/bin/materialize.js"></script>

      <script>
          $( document ).ready(function() {
              $(".dropdown-button").dropdown();
              $('.modal').modal();
              $('.datepicker').pickadate({
                selectMonths: true, // Creates a dropdown to control month
                selectYears: 90 // Creates a dropdown of 15 years to control year
              });
          });
      </script>

      <ul id="dropdown1" class="dropdown-content">
        <li><a href="#modal_account" ><?php echo e(Auth::user()->name); ?></a></li>
        <li><a href="<?php echo e(url('/logout')); ?>"
            onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();">
            Logout
        </a>

        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form></li>
      </ul>

      <div class="navbar-fixed">
      <nav>
        <div class="nav-wrapper">
          <a href="../admin" class="brand-logo"><?php echo e(config('app.name')); ?></a>
          <ul class="right">
            <li><a class="dropdown-button" href="#!" data-activates="dropdown1"><?php echo e(Auth::user()->name); ?><i class="material-icons right">arrow_drop_down</i></a></li>
          </ul>
        </div>
      </nav>
    </div>
  </br>

  <?php if(count($errors) > 0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <script>
          Materialize.toast('<?php echo e($error); ?>', 3000, 'rounded');
        </script>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  <?php endif; ?>

    <div class="container">
      <nav class="grey lighten-3" style="    box-shadow: none;">
        <div class="nav-wrapper">
          <div class="col s12">
            <a href="../admin" class="breadcrumb grey-text">Home</a>
            <a href="#" class="breadcrumb black-text"><?php echo e(Auth::user()->name); ?></a>
          </div>
        </div>
      </nav>
      <div class="black-text menu-item">Edit account</div>
      </br>
      <a href="#account_modal" class="waves-effect waves-light btn">Change password</a>
</br></br>

      <div class="row">
        <form class="col s12" action="../admin/account/editinfo" method="POST">
          <?php echo e(csrf_field()); ?>

        <div class="col s12">
          <div class="card-panel white">
            <div class="row">
              <div class="input-field col s8">
                <input id="name" type="text" name="name" class="validate" required value="<?php echo e(Auth::user()->name); ?>">
                <label for="name">First Name</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s8">
                <input id="lastname" type="text" name="lastname" class="validate" required value="<?php echo e(Auth::user()->lastname); ?>">
                <label for="name">Last Name</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s8">
                <input id="middlename" type="text" name="middlename" class="validate" required value="<?php echo e(Auth::user()->middlename); ?>">
                <label for="name">Middle Name</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s8">
                <input id="username" type="text" name="username" class="validate" required value="<?php echo e(Auth::user()->username); ?>">
                <label for="name">Username</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s8">
                <input type="date" class="datepicker" name="birthday" value="<?php echo e(Auth::user()->birthday); ?>">
                <label>Birthday</label>
              </div>
            </div>

            <button class="btn waves-effect waves-light" type="submit" name="action">Update
            </button>

          </div>
        </div>
      </form>
      </div>
    </div>

    <div id="account_modal" class="modal">
      <div class="modal-content">
        <span class="card-title menu-item">Change password</span>
      </br></br>
        <div class="row">
          <form class="col s12" action="../admin/account/changepassword" method="POST">
            <div class="row">
              <div class="input-field col s12 m6">
                <input name ="old_password" id="old_password" type="password" class="validate">
                <label for="old_password">Old password</label>
              </div>
            </div>
            <?php echo e(csrf_field()); ?>

            <div class="row">
              <div class="input-field col s12 m6">
                <input id="password" name="password" type="password" class="validate" required>
                <label for="grade_level">New password</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12 m6">
                <input id="password-confirm" name="password_confirmation" type="password" class="validate" required>
                <label for="grade_level">Confirm new password</label>
              </div>
            </div>

        </div>
      </div>
      <div class="modal-footer">
        <button class="btn waves-effect waves-light" type="submit" name="action">Update
        </button>
      </div>
      </form>
    </div>

    </body>
  </html>
