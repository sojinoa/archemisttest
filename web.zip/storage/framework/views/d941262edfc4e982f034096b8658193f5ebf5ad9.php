<html>
    <head>
      <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../../css/materialize.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

      <title><?php echo e(config('app.name')); ?> - <?php echo e($teacher->name); ?></title>
      <link rel="shortcut icon" type="image/png" href="../../images/favico.png"/>


    </head>

    <body class="grey lighten-3">
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="../../js/bin/materialize.js"></script>

      <script>
          $( document ).ready(function() {
              $(".dropdown-button").dropdown();
              $('.modal').modal();
              $('.datepicker').pickadate({
                selectMonths: true, // Creates a dropdown to control month
                selectYears: 90 // Creates a dropdown of 15 years to control year
              });
          });
      </script>

      <ul id="dropdown1" class="dropdown-content">
        <li><a href="#modal_account" ><?php echo e(Auth::user()->name); ?></a></li>
        <li><a href="<?php echo e(url('/logout')); ?>"
            onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();">
            Logout
        </a>

        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form></li>
      </ul>

      <div class="navbar-fixed">
      <nav>
        <div class="nav-wrapper">
          <a href="../../admin" class="brand-logo"><?php echo e(config('app.name')); ?></a>
          <ul class="right">
            <li><a class="dropdown-button" href="#!" data-activates="dropdown1"><?php echo e(Auth::user()->name); ?><i class="material-icons right">arrow_drop_down</i></a></li>
          </ul>
        </div>
      </nav>
    </div>
  </br>
    <div class="container">
      <nav class="grey lighten-3" style="    box-shadow: none;">
        <div class="nav-wrapper">
          <div class="col s12">
            <a href="../../admin" class="breadcrumb grey-text">Home</a>
            <a href="../teacher" class="breadcrumb grey-text">Teachers</a>
            <a href="#" class="breadcrumb black-text"><?php echo e($teacher->lastname); ?>, <?php echo e($teacher->name); ?></a>
          </div>
        </div>
      </nav>
    </br></br>

        <div class="black-text menu-item" style="font-size: 20px;"><?php echo e($teacher->lastname); ?>, <?php echo e($teacher->name); ?></div>
        <div class="black-text sub-menu-item">Username: <?php echo e($teacher->username); ?></div>
        <div class="black-text sub-menu-item">Employee ID: <?php echo e($teacher->teacher_info->employee_id); ?></div>
        <a href="#modal_edit" class="waves-effect waves-light btn">Change password</a>

        <?php if($teacher->teacher_info->is_active == 1): ?>
          <a href="#modal_delete" class="waves-effect waves-light btn red lighten-1">Set as inactive</a>
        <?php else: ?>
          <a href="#modal_delete" class="waves-effect waves-light btn green lighten-1">Set as active</a>
        <?php endif; ?>
        </br></br>

        <div class="row">

          <a href="../../admin/teacher/<?php echo e($teacher->teacher_info->employee_id); ?>/sections">
            <div class="col s12 m4">
              <div class="card small white waves-effect">
                <div class="valign-wrapper " style="height: 100%">
                    <div class="valign" style="width:100%">

                      <div class="center-align">
                          <img src="../../images/layers.png"/>
                          <div class="black-text menu-item">Sections</div>
                          <div class="grey-text submenu-item">Manage teacher's students</div>
                      </div>

                    </div>
                </div>
              </div>
            </div>
          </a>

          <a href="../../admin/teacher/<?php echo e($teacher->teacher_info->employee_id); ?>/files">
            <div class="col s12 m4">
              <div class="card small white waves-effect">
                <div class="valign-wrapper " style="height: 100%">
                    <div class="valign" style="width:100%">

                      <div class="center-align">
                          <img src="../../images/folder (1).png"/>
                          <div class="black-text menu-item">Files</div>
                          <div class="grey-text submenu-item">Manage teacher's files</div>
                      </div>

                    </div>
                </div>
              </div>
            </div>
          </a>

          <a href="../../admin/teacher/<?php echo e($teacher->teacher_info->employee_id); ?>/quizzes">
            <div class="col s12 m4">
              <div class="card small white waves-effect">
                <div class="valign-wrapper " style="height: 100%">
                    <div class="valign" style="width:100%">

                      <div class="center-align">
                          <img src="../../images/notepad.png"/>
                          <div class="black-text menu-item">Quizzes</div>
                          <div class="grey-text submenu-item">View teacher's quizzes</div>
                      </div>

                    </div>
                </div>
              </div>
            </div>
          </a>

        </div>

    </div>

    <div id="sections_modal" class="modal">
      <div class="modal-content">
        <h5>Add section</h5>
        <div class="row">

          <?php if(count($available_sections) > 0): ?>
            <?php $__currentLoopData = $available_sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="col s12 m4">
                  <div class="card white xsmall">
                    <div class="valign-wrapper " style="height: 100%">
                        <div class="valign waves-dark" style="width:100%">

                          <div class="center-align">
                              <img src="../../images/star.png"/>
                              </br>
                              <div class="black-text menu-item"><?php echo e($section->grade_level); ?></div>
                              <div class="black-text sub-menu-item"><?php echo e($section->name); ?></div>
                              </br>
                              <form action="../../admin/teacher/<?php echo e($teacher->teacher_info->employee_id); ?>/<?php echo e($section->id); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <button class="btn waves-effect waves-light blue accent-4" type="submit" name="action">Add
                                </button>
                              </form>
                          </div>
                        </div>
                    </div>
                  </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          <?php endif; ?>

        </div>
      </div>
    </div>

    <div id="modal_edit" class="modal">
        <div class="modal-content">
          <span class="card-title menu-item">Change password</span>
        </br></br>
          <div class="row">
            <form class="col s12" action="../../admin/teacheredit/<?php echo e($teacher->teacher_info->employee_id); ?>" method="POST">
              <?php echo e(csrf_field()); ?>

              <div class="row">
                <div class="input-field col s4">
                  <input id="password" name="password" type="password" class="validate" required>
                  <label for="grade_level">New password</label>
                </div>
              </div>
              <div class="row">
                <div class="input-field col s4">
                  <input id="password-confirm" name="password_confirmation" type="password" class="validate" required>
                  <label for="grade_level">Confirm new password</label>
                </div>
              </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn waves-effect waves-light" type="submit" name="action">Update
          </button>
        </div>
        </form>
      </div>

      <div id="modal_delete" class="modal">
          <div class="modal-content">
            <span class="card-title menu-item">Change status</span>
          </br></br>
            <div class="row">
              <form class="col s12" action="../../admin/teacheredit/<?php echo e($teacher->teacher_info->employee_id); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="delete">
                <p>Are you sure you want to change status of teacher <?php echo e($teacher->name); ?> ?</p>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn waves-effect waves-light red" type="submit" name="action">CHANGE
            </button>
          </div>
          </form>
        </div>



        <div id="inactive_modal" class="modal">
          <div class="modal-content">
            <h4>Inactive</h4>
            <p>This teacher is inactive, adding of section for this teacher is disabled</p>
          </div>
          <div class="modal-footer">
            <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat ">Dismiss</a>
          </div>
        </div>
        <?php if($teacher->teacher_info->is_active == 0): ?>
          <script>
          $(document).ready(function(){
            // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
            $('#inactive_modal').modal('open');

          });
          </script>
        <?php endif; ?>
    </body>
  </html>
