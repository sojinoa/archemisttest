<html>
    <head>
      <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../../../css/materialize.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

      <title><?php echo e(config('app.name')); ?> - Questions Stage <?php echo e($stage); ?></title>
      <link rel="shortcut icon" type="image/png" href="../../../images/favico.png"/>


    </head>

    <body class="grey lighten-3">
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="../../../js/bin/materialize.js"></script>

      <script>
          $( document ).ready(function() {
              $(".dropdown-button").dropdown();
              $('.modal').modal();
              $('select').material_select();
          });
      </script>

      <ul id="dropdown1" class="dropdown-content">
        <li><a href="#modal_account" ><?php echo e(Auth::user()->name); ?></a></li>
        <li><a href="<?php echo e(url('/logout')); ?>"
            onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();">
            Logout
        </a>

        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form></li>
      </ul>

      <div class="navbar-fixed">
      <nav>
        <div class="nav-wrapper">
          <a href="../../../admin" class="brand-logo"><?php echo e(config('app.name')); ?></a>
          <ul class="right">
            <li><a class="dropdown-button" href="#!" data-activates="dropdown1"><?php echo e(Auth::user()->name); ?><i class="material-icons right">arrow_drop_down</i></a></li>
          </ul>
        </div>
      </nav>
    </div>
  </br>
  <?php if(count($errors) > 0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <script>
          Materialize.toast('<?php echo e($error); ?>', 3000, 'rounded');
        </script>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  <?php endif; ?>
    <div class="container">
      <nav class="grey lighten-3" style="    box-shadow: none;">
        <div class="nav-wrapper">
          <div class="col s12">
            <a href="../../../admin" class="breadcrumb grey-text">Home</a>
            <a href="../../../admin/teacher" class="breadcrumb grey-text">Teachers</a>
            <a href="../../teacher/<?php echo e($teacher->teacher_info->employee_id); ?>" class="breadcrumb grey-text"><?php echo e($teacher->lastname); ?>, <?php echo e($teacher->name); ?></a>
            <a href="../../teacher/<?php echo e($teacher->teacher_info->employee_id); ?>/quizzes" class="breadcrumb grey-text">Stages - Quizzes</a>
            <a href="#" class="breadcrumb black-text">
              <?php if($stage == 1): ?>
                Covalent Bonding
              <?php elseif($stage == 2): ?>
                Polar Covalent Bonding
              <?php elseif($stage == 3): ?>
                Ionic Bonding
              <?php elseif($stage == 4): ?>
                Metallic Bonding
              <?php elseif($stage == 5): ?>
                Hydrogen Bonding
              <?php endif; ?>
            </a>
          </div>
        </div>
      </nav>
    </br></br>
    <div class="black-text menu-item">
      <?php if($stage == 1): ?>
        Covalent Bonding
      <?php elseif($stage == 2): ?>
        Polar Covalent Bonding
      <?php elseif($stage == 3): ?>
        Ionic Bonding
      <?php elseif($stage == 4): ?>
        Metallic Bonding
      <?php elseif($stage == 5): ?>
        Hydrogen Bonding
      <?php endif; ?>
    </div>

    <div class="row">

        <?php if(count($questions) > 0): ?>
          <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <a href="#question_moda_<?php echo e($question->id); ?>">
                <div class="col s12 m4">
                  <div class="card small white waves-effect ">
                    <div class="valign-wrapper " style="height: 100%">
                        <div class="valign" style="width:100%">

                          <div class="center-align">
                              <img src="../../../images/note.png"/>
                              </br>
                              <?php if(strlen($question->title) > 100): ?>
                                <div class="black-text menu-item"><?php echo e(substr($question->title, 0, 100)); ?>...</div>
                              <?php else: ?>
                                <div class="black-text menu-item"><?php echo e($question->title); ?></div>
                              <?php endif; ?>
                              <?php
                                  if ($question->answer == 'a') {
                                      $answer = $question->choice_1;
                                  }
                                  if ($question->answer == 'b') {
                                      $answer = $question->choice_2;
                                  }
                                  if ($question->answer == 'c') {
                                      $answer = $question->choice_3;
                                  }
                                  if ($question->answer == 'd') {
                                      $answer = $question->choice_4;
                                  }
                                ?>

                                <?php if(strlen($answer > 100)): ?>
                                  <div class="black-text menu-item"><?php echo e(substr($answer, 0, 100)); ?>...</div>
                                <?php else: ?>
                                  <div class="black-text sub-menu-item"><?php echo e($answer); ?></div>
                                <?php endif; ?>

                          </div>
                        </div>
                    </div>
                  </div>
                </div>
              </a>

              <div id="question_<?php echo e($question->id); ?>" class="modal modal-fixed-footer">
                <div class="modal-content">
                  <span class="card-title menu-item">Edit Question</span>
                  </br></br>
                  <form class="col s12" action="../../teacher/editquestion/<?php echo e($question->id); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                      <div class="input-field col s12">
                        <input placeholder="Question" value="<?php echo e($question->title); ?>" id="question" name="title" type="text" class="validate" required>
                        <label for="title">Question</label>
                      </div>
                    </div>
                    <span class="card-title sub-menu-item">Choices</span></br></br>
                    <div class="row">
                      <div class="input-field col s12">
                        <input placeholder="Choice A" value="<?php echo e($question->choice_1); ?>" id="choice_a" name="choice_a" type="text" class="validate" required>
                        <label for="title">Choice A</label>
                      </div>
                    </div>
                    <div class="row">
                      <div class="input-field col s12">
                        <input placeholder="Choice B" value="<?php echo e($question->choice_2); ?>" id="choice_b" name="choice_b" type="text" class="validate" required>
                        <label for="title">Choice B</label>
                      </div>
                    </div>
                    <div class="row">
                      <div class="input-field col s12">
                        <input placeholder="Choice C" value="<?php echo e($question->choice_3); ?>" id="choice_c" name="choice_c" type="text" class="validate" required>
                        <label for="title">Choice C</label>
                      </div>
                    </div>
                    <div class="row">
                      <div class="input-field col s12">
                        <input placeholder="Choice D" value="<?php echo e($question->choice_4); ?>" id="choice_d" name="choice_d" type="text" class="validate" required>
                        <label for="title">Choice D</label>
                      </div>
                    </div>
                    <div class="row">
                      <div class="input-field col s12">
                        <select name="answer">
                          <option <?php echo e($question->answer == 'a' ? "selected='selected'" : ""); ?> value="a">Choice A</option>
                          <option <?php echo e($question->answer == 'b' ? "selected='selected'" : ""); ?> value="b">Choice B</option>
                          <option <?php echo e($question->answer == 'c' ? "selected='selected'" : ""); ?> value="c">Choice C</option>
                          <option <?php echo e($question->answer == 'd' ? "selected='selected'" : ""); ?> value="d">Choice D</option>
                        </select>
                        <label>Answer</label>
                      </div>
                    </div>
                </div>
                <div class="modal-footer">
                  <button class="btn waves-effect waves-light btn-flat" type="submit" name="action">Update
                  </button>
                  <a href="#delete_<?php echo e($question->id); ?>" class="btn btn-flat red-text modal-action modal-close">DELETE</a>
                </div>
                </form>

              </div>

              <!-- Modal Structure -->
              <div id="delete_<?php echo e($question->id); ?>" class="modal">
                <div class="modal-content">
                  <span class="card-title menu-item">Delete</span>
                  <p>Are you sure you want to delete <?php echo e($question->title); ?>?</p>
                </div>
                <div class="modal-footer">
                  <form action="../../teacher/editquestion/<?php echo e($question->id); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="delete">
                  <button class="btn waves-effect waves-light btn-flat red-text" type="submit" name="action">DELETE
                  </button>
                  </form>
                </div>
              </div>

              <div id="question_moda_<?php echo e($question->id); ?>" class="modal">
                <div class="modal-content">
                  <span class="card-title menu-item">Question</span>
                </br></br>
                  <p><?php echo e($question->title); ?></p>

                  <p>A. <?php echo e($question->choice_1); ?></p>
                  <p>B. <?php echo e($question->choice_2); ?></p>
                  <p>C. <?php echo e($question->choice_3); ?></p>
                  <p>D. <?php echo e($question->choice_4); ?></p>

                  <p><b>Answer - <?php echo e(title_case($question->answer)); ?></b></p>
                </div>
                <div class="modal-footer">
                  <a href="#!" class=" modal-action modal-close waves-effect waves-green btn-flat">Dismiss</a>
                </div>
              </div>


              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <?php else: ?>
              <div class="black-text sub-menu-item">No questions found</div>

              <script>
              $(document).ready(function(){
                $('#no_data_modal').modal('open');

              });
              </script>

              <div id="no_data_modal" class="modal">
                <div class="modal-content">
                  <h4>No questions found</h4>
                  <p>There is no question available</p>
                </div>
                <div class="modal-footer">
                  <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat ">Dismiss</a>
                </div>
              </div>
            <?php endif; ?>

    </div>
    </div>
    </body>
  </html>
