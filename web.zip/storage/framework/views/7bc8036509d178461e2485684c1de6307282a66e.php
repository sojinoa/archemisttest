<html>
    <head>
      <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../../css/materialize.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

      <title><?php echo e(config('app.name')); ?> - <?php echo e($section->grade_level); ?> <?php echo e($section->name); ?></title>
      <link rel="shortcut icon" type="image/png" href="../../images/favico.png"/>

    </head>

    <body class="grey lighten-3">
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="../../js/bin/materialize.js"></script>

      <script>
          $( document ).ready(function() {
              $(".dropdown-button").dropdown();
              $('.modal').modal();
          });
      </script>

      <ul id="dropdown1" class="dropdown-content">
        <li><a href="#modal_account" ><?php echo e(Auth::user()->name); ?></a></li>
        <li><a href="<?php echo e(url('/logout')); ?>"
            onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();">
            Logout
        </a>

        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form></li>
      </ul>

      <div class="navbar-fixed">
      <nav>
        <div class="nav-wrapper">
          <a href="../../admin" class="brand-logo"><?php echo e(config('app.name')); ?></a>
          <ul class="right">
            <li><a class="dropdown-button" href="#!" data-activates="dropdown1"><?php echo e(Auth::user()->name); ?><i class="material-icons right">arrow_drop_down</i></a></li>
          </ul>
        </div>
      </nav>
    </div>
  </br>
    <div class="container">
      <nav class="grey lighten-3" style="    box-shadow: none;">
        <div class="nav-wrapper">
          <div class="col s12">
            <a href="../../teacher" class="breadcrumb grey-text">Home</a>
            <a href="../sections" class="breadcrumb grey-text">Sections</a>
            <a href="#" class="breadcrumb black-text"><?php echo e($section->grade_level); ?> - <?php echo e($section->name); ?></a>
          </div>
        </div>
      </nav>

    </br></br>
      <div class="black-text menu-item" style="font-size: 20px;"><?php echo e($section->grade_level); ?> - <?php echo e($section->name); ?></div>
      <div class="black-text sub-menu-item"><?php echo e($section->teacher_info != null ? $section->teacher_info->name ." ". $section->teacher_info->lastname  : 'No teacher assigned'); ?></div>
      </br>
      <div class="black-text menu-item">Students</div>
      <div class="row">
        <?php if(count($errors) > 0): ?>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <script>
                Materialize.toast('<?php echo e($error); ?>', 3000, 'rounded');
              </script>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php endif; ?>

        <?php if(count($students) > 0): ?>
          <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <a href="../../teacher/student/<?php echo e($student->student_id); ?>">
                <div class="col s12 m4">
                  <div class="card small white waves-effect">
                    <div class="valign-wrapper " style="height: 100%">
                        <div class="valign" style="width:100%">

                          <div class="center-align">
                              <img src="../../images/id-card.png"/>
                              <div class="black-text menu-item"><?php echo e($student->lastname); ?>, <?php echo e($student->name); ?></div>
                              <div class="grey-text submenu-item"><?php echo e($student->student_id); ?></div>
                            </br>
                            <?php if(!$student->is_confirmed): ?>
                              <a href="#modal_confirm_<?php echo e($student->id); ?>" class="waves-effect waves-light btn green lighten-1">Confirm</a>
                              <a href="#modal_decline_<?php echo e($student->id); ?>" class="waves-effect waves-light btn red lighten-1">Decline</a>
                            <?php endif; ?>
                          </div>

                        </div>
                    </div>
                  </div>
                </div>
              </a>

              <div id="modal_confirm_<?php echo e($student->id); ?>" class="modal">
                  <div class="modal-content">
                    <span class="card-title menu-item">Confirm student</span>
                    <div class="row">
                      <form class="col s12" action="../../teacherconfirmstudent/<?php echo e($student->student_id); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <p>Confirm that <?php echo e($student->name); ?> from <?php echo e($section->grade_level); ?> - <?php echo e($section->name); ?> is your student?</p>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button class="btn waves-effect waves-light green" type="submit" name="action">Confirm
                    </button>
                  </div>
                  </form>
                </div>

                <div id="modal_decline_<?php echo e($student->id); ?>" class="modal">
                    <div class="modal-content">
                      <span class="card-title menu-item">Confirm student</span>
                      <div class="row">
                        <form class="col s12" action="../../teacherdeclinestudent/<?php echo e($student->student_id); ?>" method="POST">
                          <?php echo e(csrf_field()); ?>

                          <p>Are you sure you want to decline <?php echo e($student->name); ?> from <?php echo e($section->grade_level); ?> - <?php echo e($section->name); ?> is your student?</p>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button class="btn waves-effect waves-light red" type="submit" name="action">Decline
                      </button>
                    </div>
                    </form>
                  </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          <?php else: ?>
          <div class="black-text sub-menu-item">No students found</div>
        <?php endif; ?>
    </div>
    </div>

    <div id="edit_section" class="modal">
        <div class="modal-content">
          <h5>Edit section</h5>
          <div class="row">
            <form class="col s12" action="../sectionedit/<?php echo e($section->id); ?>" method="POST">
              <?php echo e(csrf_field()); ?>

              <div class="row">
                <div class="input-field col s4">
                  <input value="<?php echo e($section->grade_level); ?>" id="grade_level" name="grade_level" type="text" class="validate" required>
                  <label for="grade_level">Grade Level</label>
                </div>
              </div>
              <div class="row">
                <div class="input-field col s8">
                  <input value="<?php echo e($section->name); ?>" id="name" type="text" name="name" class="validate" required>
                  <label for="name">Name</label>
                </div>
              </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn waves-effect waves-light" type="submit" name="action">Update
          </button>
        </div>
        </form>
      </div>

      <div id="modal_delete" class="modal">
          <div class="modal-content">
            <h5>Delete user</h5>
            <div class="row">
              <form class="col s12" action="../sectionedit/<?php echo e($section->id); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="delete">
                <p>Are you sure you want to delete <?php echo e($section->grade_level); ?> <?php echo e($section->name); ?> ?</p>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn waves-effect waves-light red" type="submit" name="action">DELETE
            </button>
          </div>
          </form>
        </div>


    </body>
  </html>
