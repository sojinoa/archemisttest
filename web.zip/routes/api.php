<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:api');

Route::post('/login', 'ApiController@login');
Route::get('/scores/{student_id}/{stage}', 'ApiController@get_previous_scores');
Route::post('/scores/{student_id}/{stage}', 'ApiController@set_score');
Route::get('/chapterlesson/{stage}', 'ApiController@get_chapter_lesson');
Route::get('/questions/{stage}/{student_id}', 'ApiController@get_random_questions');
Route::get('/files/{student_id}/{stage}', 'ApiController@get_teacher_files');
Route::get('/reloadstudent/{student_id}', 'ApiController@reload_student');
Route::get('/get_element/{symbol}', 'ElementController@get_element');
