<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();
Route::get('/register','HomeController@index');

Route::get('/home', 'HomeController@index');

Route::group(['middleware' => ['admin']], function () {
  Route::get('/admin', 'AdminController@home');

  Route::get('/admin/section', 'AdminController@section');
  Route::get('/admin/teacher', 'AdminController@teacher');
  Route::get('/admin/student', 'AdminController@student');
  Route::get('/admin/cluster', 'AdminController@cluster');
  Route::get('/admin/account', 'AdminController@account');

  Route::post('/admin/account/editinfo', 'AdminController@editinfo');
  Route::post('/admin/account/changepassword', 'AdminController@changepassword');

  Route::get('/admin/cluster/chapterlesson/{stage}', 'ClusterController@admin_get_chapter_lesson');
  Route::post('/admin/cluster/changepassword', 'ClusterController@admin_change_password');

  Route::get('/admin/section/{section_id}', 'SectionController@get_section');

  Route::get('/admin/teacher/{employee_id}', 'TeacherController@get_teacher');
  Route::get('/admin/teacher/{employee_id}/sections', 'TeacherController@get_teacher_sections');
  Route::get('/admin/teacher/{employee_id}/files', 'TeacherController@display_teacher_stages_files');
  Route::get('/admin/teacher/{employee_id}/files/{stage}', 'TeacherController@display_teacher_files');
  Route::get('/admin/teacher/{employee_id}/quizzes', 'TeacherController@display_teacher_stages_quizzes');


  Route::post('/admin/teacher/{employee_id}/{section_id}', 'TeacherController@add_section_to_teacher');
  Route::post('/admin/teacheredit/{employee_id}', 'TeacherController@edit_teacher');
  Route::delete('/admin/teacheredit/{employee_id}', 'TeacherController@delete_teacher');

  Route::post('/admin/sectionedit/{section_id}', 'SectionController@edit_section');
  Route::delete('/admin/sectionedit/{section_id}', 'SectionController@delete_section');
  Route::delete('/admin/sectionremovefromteach/{section_id}', 'SectionController@remove_section_from_teach');
  Route::delete('/admin/sectionremovestudent/{section_id}/{student_id}', 'SectionController@remove_student_from_section'); //The auto gen ID

  Route::post('/admin/sectionaddstudent/{student_id}', 'SectionController@add_student_to_section');

  Route::post('/admin/section/add', 'SectionController@add_section');
  Route::post('/admin/teacher/add', 'TeacherController@add_teacher');
  Route::post('/admin/student/add', 'StudentController@add_student');

  Route::delete('/admin/student/delete/{student_id}', 'StudentController@delete_student'); //The auto gen ID
  Route::delete('/admin/student/changestatus/{student_id}', 'StudentController@change_status');

  Route::delete('/admin/deletefile/{employee_id}/{file_id}', 'FileController@admin_delete_file');

  Route::get('/admin/questions/{teacher_id}/{stage}', 'QuestionController@admin_get_questions');

});

Route::group(['middleware' => ['cluster']], function () {
  Route::get('/cluster', 'ClusterController@index');
  Route::get('/cluster/stages', 'ClusterController@stages');
  Route::get('/cluster/chapterlesson/{stage}', 'ChapterLessonController@get_chapter_lesson');

  Route::post('/cluster/chapterlesson/{stage}', 'ChapterLessonController@edit_lesson');
  Route::get('/cluster/periodictable', 'ClusterController@periodictable');

  Route::post('/cluster/periodictable/{symbol}', 'ElementController@edit_element_uses');
});

Route::group(['middleware' => ['teacher']], function () {
  Route::get('/teacher', 'TeacherController@user_get_teacher');
  Route::get('/teacher/section/{section_id}', 'SectionController@user_get_section');

  Route::post('/teacherconfirmstudent/{student_id}', 'StudentController@confirm_student');
  Route::post('/teacherdeclinestudent/{student_id}', 'StudentController@decline_student');

  Route::post('/teacher/addfile/{stage}', 'TeacherController@add_file');

  Route::get('/teacher/sections', 'TeacherController@user_sections');
  Route::get('/teacher/files', 'TeacherController@file_stages');
  Route::get('/teacher/files/{stage}', 'TeacherController@user_files');

  Route::get('/teacher/quizzes', 'TeacherController@user_quizzes');
  Route::get('/teacher/questions/{stage}', 'QuestionController@get_questions');

  Route::post('/teacher/addquestion/{stage}', 'QuestionController@add_question');
  Route::post('/teacher/editquestion/{question_id}', 'QuestionController@update_question');
  Route::delete('/teacher/editquestion/{question_id}', 'QuestionController@delete_question');

  Route::delete('/teacher/file/{file_id}/{stage}', 'FileController@delete_file');

  Route::get('/teacher/student/{student_id}', 'StudentController@user_get_student');
});
